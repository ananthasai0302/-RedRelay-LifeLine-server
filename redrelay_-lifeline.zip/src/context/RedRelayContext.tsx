import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
} from '../firebase';
import type {
  BloodGroup,
  BloodKind,
  BloodRequest,
  Donor,
  DonorResponse,
  RequestStatus,
  SmsDispatchLog,
  UrgencyLevel,
  UserPrivateProfile,
} from '../types/redrelay';
import { createSeedData, HOSPITALS, LOCALITIES } from '../data/seedData';
import {
  estimateDriveMinutes,
  extractInitials,
  getRecoveryStatus,
  haversineDistanceKm,
  isCompatibleDonor,
  maskPhoneNumber,
  RECOVERY_LOCK_DAYS,
} from '../utils/compatibility';

export interface ToastMessage {
  id: string;
  title: string;
  detail?: string;
  tone: 'success' | 'alert' | 'info';
}

export interface CreateSosInput {
  patientName: string;
  hospitalId: string;
  customHospitalName?: string;
  customCity?: string;
  customLocality?: string;
  bloodGroup: BloodGroup;
  bloodKind: BloodKind;
  unitsNeeded: number;
  urgencyLevel: UrgencyLevel;
  deadlineHours: number;
  doctorContact: string;
  clinicalNotes: string;
}

export interface RegisterDonorInput {
  fullName: string;
  bloodGroup: BloodGroup;
  city: string;
  locality: string;
  phone: string;
  initialUnitsGiven: number;
}

interface RedRelayContextValue {
  user: User | null;
  authReady: boolean;
  firestoreConnected: boolean;
  privateProfile: UserPrivateProfile | null;
  donors: Donor[];
  requests: BloodRequest[];
  responses: DonorResponse[];
  smsLogs: SmsDispatchLog[];
  activeDonorId: string;
  nowMs: number;
  toasts: ToastMessage[];
  signInWithGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;
  setActiveDonorId: (donorId: string) => void;
  dismissToast: (id: string) => void;
  pushToast: (toast: Omit<ToastMessage, 'id'>) => void;
  createSosRequest: (input: CreateSosInput) => Promise<{
    request: BloodRequest;
    dispatchedCount: number;
  } | null>;
  commitToRequest: (
    requestId: string,
    donorId: string,
    unitsToGive?: number
  ) => Promise<boolean>;
  markBloodReceived: (requestId: string) => Promise<void>;
  advanceRequestStatus: (
    requestId: string,
    status: RequestStatus
  ) => Promise<void>;
  dispatchSmsBroadcast: (
    requestId: string,
    radiusKm?: number
  ) => Promise<number>;
  registerDonor: (input: RegisterDonorInput) => Promise<Donor | null>;
  toggleDonorAvailability: (donorId: string) => Promise<void>;
  getEligibleDonorsForRequest: (
    request: BloodRequest,
    radiusKm?: number
  ) => Array<Donor & { distanceKm: number; etaMinutes: number }>;
  resetDemoData: () => Promise<void>;
}

const RedRelayContext = createContext<RedRelayContextValue | null>(null);

function toIsoString(val: unknown): string {
  if (!val) return new Date().toISOString();
  if (typeof val === 'string') return val;
  if (val instanceof Timestamp) return val.toDate().toISOString();
  if (typeof (val as { toDate?: () => Date }).toDate === 'function') {
    return (val as { toDate: () => Date }).toDate().toISOString();
  }
  return new Date().toISOString();
}

export function RedRelayProvider({ children }: { children: React.ReactNode }) {
  const [seed] = useState(() => createSeedData());

  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [firestoreConnected, setFirestoreConnected] = useState(false);
  const [privateProfile, setPrivateProfile] =
    useState<UserPrivateProfile | null>(null);

  const [donors, setDonors] = useState<Donor[]>(seed.donors);
  const [requests, setRequests] = useState<BloodRequest[]>(seed.requests);
  const [responses, setResponses] = useState<DonorResponse[]>(seed.responses);
  const [smsLogs, setSmsLogs] = useState<SmsDispatchLog[]>(seed.smsLogs);
  const [activeDonorId, setActiveDonorId] = useState<string>('donor-01');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [nowMs, setNowMs] = useState<number>(() => Date.now());

  // Live clock tick every 15s for real-time countdowns
  useEffect(() => {
    const interval = window.setInterval(() => {
      setNowMs(Date.now());
    }, 15000);
    return () => window.clearInterval(interval);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const pushToast = useCallback((toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev.slice(-3), { ...toast, id }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4800);
  }, []);

  // Firebase Auth listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  // Seed Firestore automatically when a verified user signs in and collections are empty
  const seedFirestoreIfEmpty = useCallback(
    async (signedInUser: User) => {
      try {
        const reqSnap = await getDocs(collection(db, 'requests'));
        const legacyBengaluruSeed = reqSnap.docs.find(
          (d) => d.id === 'SOS-4091' && d.data()?.city === 'Bengaluru'
        );
        const canMigrateLegacy =
          Boolean(legacyBengaluruSeed) &&
          (legacyBengaluruSeed?.data()?.creatorUid === signedInUser.uid ||
            signedInUser.email === 'sanjanamourya029@gmail.com');
        if (!reqSnap.empty && !canMigrateLegacy) return;

        const batch = writeBatch(db);
        const fresh = createSeedData();

        for (const donor of fresh.donors) {
          const ref = doc(db, 'donors', donor.id);
          batch.set(ref, {
            id: donor.id,
            ownerUid: signedInUser.uid,
            initials: donor.initials,
            displayName: donor.initials,
            bloodGroup: donor.bloodGroup,
            city: donor.city,
            locality: donor.locality,
            lat: donor.lat,
            lng: donor.lng,
            maskedPhone: donor.maskedPhone,
            relayCode: donor.relayCode,
            isAvailable: donor.isAvailable,
            lastDonationDate: donor.lastDonationDate,
            lockedUntil: donor.lockedUntil,
            totalDonations: donor.totalDonations,
            totalUnitsGiven: donor.totalUnitsGiven,
            verified: donor.verified,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }

        for (const req of fresh.requests) {
          const ref = doc(db, 'requests', req.id);
          batch.set(ref, {
            id: req.id,
            creatorUid: signedInUser.uid,
            patientName: req.patientName,
            hospitalId: req.hospitalId,
            hospitalName: req.hospitalName,
            city: req.city,
            locality: req.locality,
            lat: req.lat,
            lng: req.lng,
            bloodGroup: req.bloodGroup,
            bloodKind: req.bloodKind,
            unitsNeeded: req.unitsNeeded,
            unitsCommitted: req.unitsCommitted,
            urgencyLevel: req.urgencyLevel,
            deadlineHours: req.deadlineHours,
            expiresAt: req.expiresAt,
            doctorContact: req.doctorContact,
            clinicalNotes: req.clinicalNotes,
            status: req.status,
            closedAt: req.closedAt,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }

        for (const resp of fresh.responses) {
          const ref = doc(db, 'responses', resp.id);
          batch.set(ref, {
            id: resp.id,
            requestId: resp.requestId,
            donorId: resp.donorId,
            donorUid: signedInUser.uid,
            donorInitials: resp.donorInitials,
            donorBloodGroup: resp.donorBloodGroup,
            donorLocality: resp.donorLocality,
            distanceKm: resp.distanceKm,
            etaMinutes: resp.etaMinutes,
            unitsCommitted: resp.unitsCommitted,
            status: resp.status,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }

        await batch.commit();
      } catch (err) {
        console.warn('Initial Firestore seed skipped or unauthorized:', err);
      }
    },
    []
  );

  // Public Firestore listeners (/donors, /requests, /responses)
  useEffect(() => {
    const unsubDonors = onSnapshot(
      collection(db, 'donors'),
      (snapshot) => {
        setFirestoreConnected(true);
        if (snapshot.empty) return;
        const nextDonors: Donor[] = snapshot.docs.map((d) => {
          const data = d.data();
          return {
            id: data.id ?? d.id,
            ownerUid: data.ownerUid ?? 'seed-system',
            fullName: data.displayName ?? data.initials ?? 'Verified Donor',
            displayName: data.displayName ?? data.initials ?? 'Verified Donor',
            initials: data.initials ?? 'D. R.',
            bloodGroup: data.bloodGroup as BloodGroup,
            city: data.city ?? 'Hyderabad, Telangana',
            locality: data.locality ?? 'Banjara Hills',
            lat: Number(data.lat ?? 17.4156),
            lng: Number(data.lng ?? 78.4347),
            maskedPhone: data.maskedPhone ?? '+91 ••••• ••000',
            relayCode: data.relayCode ?? 'RLY-0000',
            isAvailable: Boolean(data.isAvailable),
            lastDonationDate: data.lastDonationDate ?? null,
            lockedUntil: data.lockedUntil ?? null,
            totalDonations: Number(data.totalDonations ?? 0),
            totalUnitsGiven: Number(
              data.totalUnitsGiven ?? data.totalDonations ?? 0
            ),
            verified: Boolean(data.verified ?? true),
          };
        });
        setDonors(nextDonors);
      },
      (error) => {
        console.warn('Donors listener warning:', error.message);
      }
    );

    const unsubRequests = onSnapshot(
      collection(db, 'requests'),
      (snapshot) => {
        setFirestoreConnected(true);
        if (snapshot.empty) return;
        const nextRequests: BloodRequest[] = snapshot.docs
          .map((d) => {
            const data = d.data();
            return {
              id: data.id ?? d.id,
              creatorUid: data.creatorUid ?? 'seed-system',
              patientName: data.patientName ?? 'Emergency Patient',
              hospitalId: data.hospitalId ?? 'custom',
              hospitalName: data.hospitalName ?? 'Partner Hospital',
              city: data.city ?? 'Hyderabad, Telangana',
              locality: data.locality ?? 'Banjara Hills',
              lat: Number(data.lat ?? 17.4156),
              lng: Number(data.lng ?? 78.4347),
              bloodGroup: data.bloodGroup as BloodGroup,
              bloodKind: (data.bloodKind ?? 'Whole Blood') as BloodKind,
              unitsNeeded: Number(data.unitsNeeded ?? 1),
              unitsCommitted: Number(data.unitsCommitted ?? 0),
              urgencyLevel: (data.urgencyLevel ?? 'Urgent') as UrgencyLevel,
              deadlineHours: Number(data.deadlineHours ?? 4),
              expiresAt: data.expiresAt ?? new Date(Date.now() + 4 * 3600000).toISOString(),
              doctorContact: data.doctorContact ?? 'Hospital Blood Bank',
              clinicalNotes: data.clinicalNotes ?? '',
              status: (data.status ?? 'Open / Broadcasted') as RequestStatus,
              createdAt: toIsoString(data.createdAt),
              closedAt: data.closedAt ?? null,
            };
          })
          .sort(
            (a, b) =>
              new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          );
        setRequests(nextRequests);
      },
      (error) => {
        console.warn('Requests listener warning:', error.message);
      }
    );

    const unsubResponses = onSnapshot(
      collection(db, 'responses'),
      (snapshot) => {
        if (snapshot.empty) return;
        const nextResponses: DonorResponse[] = snapshot.docs.map((d) => {
          const data = d.data();
          return {
            id: data.id ?? d.id,
            requestId: data.requestId,
            donorId: data.donorId,
            donorUid: data.donorUid ?? 'seed-system',
            donorInitials: data.donorInitials ?? 'D. R.',
            donorBloodGroup: data.donorBloodGroup as BloodGroup,
            donorLocality: data.donorLocality ?? 'Banjara Hills',
            distanceKm: Number(data.distanceKm ?? 2),
            etaMinutes: Number(data.etaMinutes ?? 10),
            unitsCommitted: Number(data.unitsCommitted ?? 1),
            status: data.status ?? 'Committed',
            createdAt: toIsoString(data.createdAt),
          };
        });
        setResponses(nextResponses);
      },
      (error) => {
        console.warn('Responses listener warning:', error.message);
      }
    );

    return () => {
      unsubDonors();
      unsubRequests();
      unsubResponses();
    };
  }, []);

  // Auth-gated listeners (/users/{uid}/private/profile and /smsLogs scoped to senderUid)
  useEffect(() => {
    if (!authReady || !user) {
      setPrivateProfile(null);
      return;
    }

    void seedFirestoreIfEmpty(user);

    const profileRef = doc(db, 'users', user.uid, 'private', 'profile');
    const unsubProfile = onSnapshot(
      profileRef,
      (snap) => {
        if (snap.exists()) {
          const data = snap.data();
          setPrivateProfile({
            uid: data.uid,
            fullName: data.fullName,
            email: data.email,
            phone: data.phone,
            maskedPhone: data.maskedPhone,
          });
        } else {
          setPrivateProfile(null);
        }
      },
      (error) => {
        handleFirestoreError(
          error,
          OperationType.GET,
          `users/${user.uid}/private/profile`
        );
      }
    );

    const smsQuery = query(
      collection(db, 'smsLogs'),
      where('senderUid', '==', user.uid)
    );
    const unsubSms = onSnapshot(
      smsQuery,
      (snap) => {
        if (snap.empty) return;
        const nextLogs: SmsDispatchLog[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: data.id ?? d.id,
              requestId: data.requestId,
              senderUid: data.senderUid,
              hospitalName: data.hospitalName,
              bloodGroup: data.bloodGroup as BloodGroup,
              donorId: data.donorId,
              donorInitials: data.donorInitials,
              donorBloodGroup: data.donorBloodGroup as BloodGroup,
              maskedPhone: data.maskedPhone,
              distanceKm: Number(data.distanceKm ?? 0),
              messagePreview: data.messagePreview,
              deliveryStatus: data.deliveryStatus ?? 'Delivered',
              sentAt: toIsoString(data.sentAt),
            };
          })
          .sort(
            (a, b) =>
              new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime()
          );
        setSmsLogs(nextLogs);
      },
      (error) => {
        console.warn('SMS logs query warning:', error.message);
      }
    );

    return () => {
      unsubProfile();
      unsubSms();
    };
  }, [authReady, user, seedFirestoreIfEmpty]);

  const signInWithGoogle = useCallback(async () => {
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      pushToast({
        tone: 'success',
        title: `Signed in as ${cred.user.displayName ?? cred.user.email}`,
        detail: 'Your actions now persist securely to Cloud Firestore.',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Sign-in cancelled.';
      pushToast({
        tone: 'alert',
        title: 'Google Sign-In Failed',
        detail: msg,
      });
    }
  }, [pushToast]);

  const signOutUser = useCallback(async () => {
    await signOut(auth);
    pushToast({
      tone: 'info',
      title: 'Signed Out',
      detail: 'Switched to public read-only view.',
    });
  }, [pushToast]);

  const getEligibleDonorsForRequest = useCallback(
    (request: BloodRequest, radiusKm: number = 25) => {
      const currentMs = Date.now();
      return donors
        .filter((donor) => {
          if (!isCompatibleDonor(donor.bloodGroup, request.bloodGroup)) return false;
          if (!donor.isAvailable) return false;
          if (getRecoveryStatus(donor, currentMs).isLocked) return false;
          const dist = haversineDistanceKm(
            request.lat,
            request.lng,
            donor.lat,
            donor.lng
          );
          return dist <= radiusKm;
        })
        .map((donor) => {
          const distanceKm = haversineDistanceKm(
            request.lat,
            request.lng,
            donor.lat,
            donor.lng
          );
          return {
            ...donor,
            distanceKm,
            etaMinutes: estimateDriveMinutes(distanceKm),
          };
        })
        .sort((a, b) => a.distanceKm - b.distanceKm);
    },
    [donors]
  );

  const requireSignedIn = useCallback((): User | null => {
    if (!user) {
      pushToast({
        tone: 'alert',
        title: 'Google Sign-In Required',
        detail:
          'Sign in with Google from the toolbar to save emergency requests, donations, or donor profiles to Firestore.',
      });
      return null;
    }
    return user;
  }, [user, pushToast]);

  const createSosRequest = useCallback(
    async (input: CreateSosInput) => {
      const activeUser = requireSignedIn();
      if (!activeUser) return null;

      const isCustomHospital = input.hospitalId === 'custom';
      const selectedHospital =
        HOSPITALS.find((h) => h.id === input.hospitalId) ?? HOSPITALS[0];

      const city = isCustomHospital
        ? input.customCity || 'Hyderabad, Telangana'
        : selectedHospital.city;
      const locality = isCustomHospital
        ? input.customLocality || 'Banjara Hills'
        : selectedHospital.locality;
      const locCoords =
        LOCALITIES.find((l) => l.city === city && l.locality === locality) ??
        selectedHospital;

      const hospitalName = isCustomHospital
        ? (input.customHospitalName || 'Custom Medical Center').trim()
        : selectedHospital.name;

      const now = Date.now();
      const cappedHours = Math.min(Math.max(input.deadlineHours, 1), 24);
      const id = `SOS-${4092 + requests.length}`;
      const expiresAt = new Date(now + cappedHours * 3600 * 1000).toISOString();

      const newRequest: BloodRequest = {
        id,
        creatorUid: activeUser.uid,
        patientName: input.patientName.trim().slice(0, 120),
        hospitalId: isCustomHospital ? 'custom-hospital' : selectedHospital.id,
        hospitalName: hospitalName.slice(0, 160),
        city,
        locality,
        lat: locCoords.lat,
        lng: locCoords.lng,
        bloodGroup: input.bloodGroup,
        bloodKind: input.bloodKind,
        unitsNeeded: input.unitsNeeded,
        unitsCommitted: 0,
        urgencyLevel: input.urgencyLevel,
        deadlineHours: cappedHours,
        expiresAt,
        doctorContact: input.doctorContact.trim().slice(0, 160),
        clinicalNotes:
          (input.clinicalNotes.trim() ||
            'Emergency blood bank cross-match desk open.').slice(0, 500),
        status: 'Open / Broadcasted',
        createdAt: new Date(now).toISOString(),
        closedAt: null,
      };

      const path = `requests/${id}`;
      try {
        await setDoc(doc(db, 'requests', id), {
          id: newRequest.id,
          creatorUid: activeUser.uid,
          patientName: newRequest.patientName,
          hospitalId: newRequest.hospitalId,
          hospitalName: newRequest.hospitalName,
          city: newRequest.city,
          locality: newRequest.locality,
          lat: newRequest.lat,
          lng: newRequest.lng,
          bloodGroup: newRequest.bloodGroup,
          bloodKind: newRequest.bloodKind,
          unitsNeeded: newRequest.unitsNeeded,
          unitsCommitted: 0,
          urgencyLevel: newRequest.urgencyLevel,
          deadlineHours: newRequest.deadlineHours,
          expiresAt: newRequest.expiresAt,
          doctorContact: newRequest.doctorContact,
          clinicalNotes: newRequest.clinicalNotes,
          status: 'Open / Broadcasted',
          closedAt: null,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, path);
      }

      const eligible = getEligibleDonorsForRequest(newRequest, 25);
      const batch = writeBatch(db);
      const newLogs: SmsDispatchLog[] = [];
      eligible.forEach((donor, idx) => {
        const logId = `sms-${now}-${idx}`;
        const logObj: SmsDispatchLog = {
          id: logId,
          requestId: newRequest.id,
          senderUid: activeUser.uid,
          hospitalName: newRequest.hospitalName,
          bloodGroup: newRequest.bloodGroup,
          donorId: donor.id,
          donorInitials: donor.initials,
          donorBloodGroup: donor.bloodGroup,
          maskedPhone: donor.maskedPhone,
          distanceKm: donor.distanceKm,
          messagePreview: `REDRELAY SOS: ${newRequest.unitsNeeded} unit(s) ${newRequest.bloodGroup} (${newRequest.bloodKind}) needed within ${cappedHours}h at ${newRequest.hospitalName}.`,
          deliveryStatus: 'Delivered',
          sentAt: new Date(now).toISOString(),
        };
        newLogs.push(logObj);
        batch.set(doc(db, 'smsLogs', logId), {
          id: logObj.id,
          requestId: logObj.requestId,
          senderUid: activeUser.uid,
          hospitalName: logObj.hospitalName,
          bloodGroup: logObj.bloodGroup,
          donorId: logObj.donorId,
          donorInitials: logObj.donorInitials,
          donorBloodGroup: logObj.donorBloodGroup,
          maskedPhone: logObj.maskedPhone,
          distanceKm: logObj.distanceKm,
          messagePreview: logObj.messagePreview.slice(0, 320),
          deliveryStatus: 'Delivered',
          sentAt: serverTimestamp(),
        });
      });

      if (newLogs.length > 0) {
        try {
          await batch.commit();
        } catch (err) {
          console.warn('SMS batch write error:', err);
        }
      }

      pushToast({
        tone: 'alert',
        title: `SOS ${newRequest.id} Broadcasted to Firestore`,
        detail: `Matched & alerted ${newLogs.length} compatible donor(s) within 25 km of ${locality}.`,
      });

      return { request: newRequest, dispatchedCount: newLogs.length };
    },
    [getEligibleDonorsForRequest, pushToast, requests.length, requireSignedIn]
  );

  const commitToRequest = useCallback(
    async (
      requestId: string,
      donorId: string,
      unitsToGive: number = 1
    ): Promise<boolean> => {
      const activeUser = requireSignedIn();
      if (!activeUser) return false;

      const request = requests.find((r) => r.id === requestId);
      const donor = donors.find((d) => d.id === donorId);
      if (!request || !donor) return false;

      if (request.status === 'Closed') {
        pushToast({
          tone: 'info',
          title: 'Request Already Closed',
          detail: 'This emergency request has already been fulfilled and closed.',
        });
        return false;
      }

      const recovery = getRecoveryStatus(donor, Date.now());
      if (recovery.isLocked) {
        pushToast({
          tone: 'alert',
          title: '90-Day Recovery Lock Active',
          detail: `Donor ${donor.initials} must wait ${recovery.daysRemaining} more day(s) before donating again.`,
        });
        return false;
      }

      if (!donor.isAvailable) {
        pushToast({
          tone: 'info',
          title: 'Donor Marked Unavailable',
          detail: 'Enable donor availability before committing to an SOS request.',
        });
        return false;
      }

      if (!isCompatibleDonor(donor.bloodGroup, request.bloodGroup)) {
        pushToast({
          tone: 'alert',
          title: 'Blood Group Incompatible',
          detail: `${donor.bloodGroup} cannot clinically donate red cells to a ${request.bloodGroup} patient.`,
        });
        return false;
      }

      const alreadyCommitted = responses.some(
        (resp) => resp.requestId === requestId && resp.donorId === donorId
      );
      if (alreadyCommitted) {
        pushToast({
          tone: 'info',
          title: 'Already Committed',
          detail: `Donor ${donor.initials} has already committed to ${request.id}.`,
        });
        return false;
      }

      const safeUnits = Math.max(
        1,
        Math.min(unitsToGive, request.unitsNeeded - request.unitsCommitted, 4)
      );
      const distanceKm = haversineDistanceKm(
        request.lat,
        request.lng,
        donor.lat,
        donor.lng
      );
      const etaMinutes = estimateDriveMinutes(distanceKm);
      const newUnitsCommitted = Math.min(
        request.unitsNeeded,
        request.unitsCommitted + safeUnits
      );
      const isFullyCommitted = newUnitsCommitted >= request.unitsNeeded;
      const nextStatus: RequestStatus = isFullyCommitted
        ? 'Fulfilled / In Transit'
        : 'Donors Responded';

      const respId = `resp-${Date.now()}`;
      try {
        await setDoc(doc(db, 'responses', respId), {
          id: respId,
          requestId,
          donorId: donor.id,
          donorUid: activeUser.uid,
          donorInitials: donor.initials,
          donorBloodGroup: donor.bloodGroup,
          donorLocality: donor.locality,
          distanceKm,
          etaMinutes,
          unitsCommitted: safeUnits,
          status: isFullyCommitted ? 'In Transit' : 'Committed',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        await updateDoc(doc(db, 'requests', requestId), {
          unitsCommitted: newUnitsCommitted,
          status: nextStatus,
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `requests/${requestId}`);
      }

      pushToast({
        tone: 'success',
        title: `${safeUnits} Unit(s) Committed to ${request.id}`,
        detail: `${donor.initials} (${donor.bloodGroup}) pledged ${safeUnits} unit(s) via private relay · ETA ~${etaMinutes} min.`,
      });
      return true;
    },
    [donors, pushToast, requests, responses, requireSignedIn]
  );

  const markBloodReceived = useCallback(
    async (requestId: string) => {
      const activeUser = requireSignedIn();
      if (!activeUser) return;

      const nowIso = new Date().toISOString();
      const lockUntilIso = new Date(
        Date.now() + RECOVERY_LOCK_DAYS * 24 * 60 * 60 * 1000
      ).toISOString();

      const matchingResponses = responses.filter(
        (r) => r.requestId === requestId
      );

      try {
        const batch = writeBatch(db);
        batch.update(doc(db, 'requests', requestId), {
          status: 'Closed',
          closedAt: nowIso,
          updatedAt: serverTimestamp(),
        });

        for (const resp of matchingResponses) {
          batch.update(doc(db, 'responses', resp.id), {
            status: 'Donated',
            updatedAt: serverTimestamp(),
          });

          const donor = donors.find((d) => d.id === resp.donorId);
          if (donor) {
            batch.update(doc(db, 'donors', donor.id), {
              isAvailable: false,
              lastDonationDate: nowIso,
              lockedUntil: lockUntilIso,
              totalDonations: donor.totalDonations + 1,
              totalUnitsGiven: donor.totalUnitsGiven + resp.unitsCommitted,
              updatedAt: serverTimestamp(),
            });
          }
        }

        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `requests/${requestId}`);
      }

      pushToast({
        tone: 'success',
        title: `${requestId} Marked Blood Received`,
        detail:
          matchingResponses.length > 0
            ? `Request closed. ${matchingResponses.length} fulfilling donor(s) placed on 90-day recovery lock.`
            : 'Request closed and removed from active urgent queue.',
      });
    },
    [donors, pushToast, responses, requireSignedIn]
  );

  const advanceRequestStatus = useCallback(
    async (requestId: string, status: RequestStatus) => {
      const activeUser = requireSignedIn();
      if (!activeUser) return;

      if (status === 'Closed') {
        await markBloodReceived(requestId);
        return;
      }

      try {
        await updateDoc(doc(db, 'requests', requestId), {
          status,
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `requests/${requestId}`);
      }

      pushToast({
        tone: 'info',
        title: `${requestId} Updated`,
        detail: `Lifecycle stage transitioned to "${status}".`,
      });
    },
    [markBloodReceived, pushToast, requireSignedIn]
  );

  const dispatchSmsBroadcast = useCallback(
    async (requestId: string, radiusKm: number = 25): Promise<number> => {
      const activeUser = requireSignedIn();
      if (!activeUser) return 0;

      const request = requests.find((r) => r.id === requestId);
      if (!request) return 0;

      const eligible = getEligibleDonorsForRequest(request, radiusKm);
      const now = Date.now();

      try {
        const batch = writeBatch(db);
        eligible.forEach((donor, idx) => {
          const logId = `sms-${now}-${idx}`;
          batch.set(doc(db, 'smsLogs', logId), {
            id: logId,
            requestId: request.id,
            senderUid: activeUser.uid,
            hospitalName: request.hospitalName,
            bloodGroup: request.bloodGroup,
            donorId: donor.id,
            donorInitials: donor.initials,
            donorBloodGroup: donor.bloodGroup,
            maskedPhone: donor.maskedPhone,
            distanceKm: donor.distanceKm,
            messagePreview: `REDRELAY SOS DISPATCH: ${request.unitsNeeded - request.unitsCommitted} unit(s) ${request.bloodGroup} (${request.bloodKind}) needed at ${request.hospitalName}.`,
            deliveryStatus: 'Delivered',
            sentAt: serverTimestamp(),
          });
        });
        if (eligible.length > 0) {
          await batch.commit();
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'smsLogs');
      }

      pushToast({
        tone: eligible.length > 0 ? 'success' : 'info',
        title:
          eligible.length > 0
            ? `Dispatched ${eligible.length} SMS Alert(s)`
            : 'No Eligible Donors in Radius',
        detail:
          eligible.length > 0
            ? `Broadcasted masked relay alerts for ${request.id} within ${radiusKm} km.`
            : `Try expanding proximity radius beyond ${radiusKm} km.`,
      });
      return eligible.length;
    },
    [getEligibleDonorsForRequest, pushToast, requests, requireSignedIn]
  );

  const registerDonor = useCallback(
    async (input: RegisterDonorInput): Promise<Donor | null> => {
      const activeUser = requireSignedIn();
      if (!activeUser) return null;

      const localityObj =
        LOCALITIES.find(
          (l) => l.city === input.city && l.locality === input.locality
        ) ?? LOCALITIES[0];
      const jitterLat = (Math.random() - 0.5) * 0.012;
      const jitterLng = (Math.random() - 0.5) * 0.012;

      const id = `donor-${Date.now()}`;
      const initials = extractInitials(input.fullName);
      const maskedPhone = maskPhoneNumber(input.phone);
      const relayCode = `RLY-${Math.floor(1000 + Math.random() * 9000)}`;

      const newDonor: Donor = {
        id,
        ownerUid: activeUser.uid,
        fullName: input.fullName.trim(),
        displayName: initials,
        initials,
        bloodGroup: input.bloodGroup,
        city: localityObj.city,
        locality: localityObj.locality,
        lat: Math.round((localityObj.lat + jitterLat) * 10000) / 10000,
        lng: Math.round((localityObj.lng + jitterLng) * 10000) / 10000,
        maskedPhone,
        relayCode,
        isAvailable: true,
        lastDonationDate: null,
        lockedUntil: null,
        totalDonations: input.initialUnitsGiven > 0 ? 1 : 0,
        totalUnitsGiven: Math.max(0, input.initialUnitsGiven),
        verified: true,
      };

      try {
        // 1. Write private PII strictly to /users/{uid}/private/profile
        await setDoc(doc(db, 'users', activeUser.uid, 'private', 'profile'), {
          uid: activeUser.uid,
          fullName: input.fullName.trim().slice(0, 120),
          email: activeUser.email ?? 'verified@redrelay.org',
          phone: input.phone.trim().slice(0, 24),
          maskedPhone,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        // 2. Write public-safe privacy-masked record to /donors/{donorId}
        await setDoc(doc(db, 'donors', id), {
          id,
          ownerUid: activeUser.uid,
          initials,
          displayName: initials,
          bloodGroup: newDonor.bloodGroup,
          city: newDonor.city,
          locality: newDonor.locality,
          lat: newDonor.lat,
          lng: newDonor.lng,
          maskedPhone,
          relayCode,
          isAvailable: true,
          lastDonationDate: null,
          lockedUntil: null,
          totalDonations: newDonor.totalDonations,
          totalUnitsGiven: newDonor.totalUnitsGiven,
          verified: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `donors/${id}`);
      }

      setActiveDonorId(id);
      pushToast({
        tone: 'success',
        title: `Donor ${initials} Saved to Firestore`,
        detail: `Blood group ${newDonor.bloodGroup} · ${newDonor.totalUnitsGiven} unit(s) logged · Phone isolated privately & masked publicly as ${maskedPhone}.`,
      });
      return newDonor;
    },
    [pushToast, requireSignedIn]
  );

  const toggleDonorAvailability = useCallback(
    async (donorId: string) => {
      const activeUser = requireSignedIn();
      if (!activeUser) return;

      const target = donors.find((d) => d.id === donorId);
      if (!target) return;

      const recovery = getRecoveryStatus(target, Date.now());
      if (recovery.isLocked) {
        pushToast({
          tone: 'alert',
          title: '90-Day Recovery Lock Enforced',
          detail: `${target.initials} cannot toggle available until ${recovery.daysRemaining} recovery day(s) remain complete.`,
        });
        return;
      }

      const nextAvailable = !target.isAvailable;
      try {
        await updateDoc(doc(db, 'donors', donorId), {
          isAvailable: nextAvailable,
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `donors/${donorId}`);
      }

      pushToast({
        tone: 'info',
        title: 'Availability Updated',
        detail: `${target.initials} is now marked ${nextAvailable ? 'Available' : 'Paused'}.`,
      });
    },
    [donors, pushToast, requireSignedIn]
  );

  const resetDemoData = useCallback(async () => {
    const activeUser = requireSignedIn();
    if (!activeUser) return;

    const fresh = createSeedData();
    try {
      const batch = writeBatch(db);
      for (const donor of fresh.donors) {
        batch.set(doc(db, 'donors', donor.id), {
          id: donor.id,
          ownerUid: activeUser.uid,
          initials: donor.initials,
          displayName: donor.initials,
          bloodGroup: donor.bloodGroup,
          city: donor.city,
          locality: donor.locality,
          lat: donor.lat,
          lng: donor.lng,
          maskedPhone: donor.maskedPhone,
          relayCode: donor.relayCode,
          isAvailable: donor.isAvailable,
          lastDonationDate: donor.lastDonationDate,
          lockedUntil: donor.lockedUntil,
          totalDonations: donor.totalDonations,
          totalUnitsGiven: donor.totalUnitsGiven,
          verified: donor.verified,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      for (const req of fresh.requests) {
        batch.set(doc(db, 'requests', req.id), {
          id: req.id,
          creatorUid: activeUser.uid,
          patientName: req.patientName,
          hospitalId: req.hospitalId,
          hospitalName: req.hospitalName,
          city: req.city,
          locality: req.locality,
          lat: req.lat,
          lng: req.lng,
          bloodGroup: req.bloodGroup,
          bloodKind: req.bloodKind,
          unitsNeeded: req.unitsNeeded,
          unitsCommitted: req.unitsCommitted,
          urgencyLevel: req.urgencyLevel,
          deadlineHours: req.deadlineHours,
          expiresAt: req.expiresAt,
          doctorContact: req.doctorContact,
          clinicalNotes: req.clinicalNotes,
          status: req.status,
          closedAt: req.closedAt,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      await batch.commit();
      setActiveDonorId('donor-01');
      pushToast({
        tone: 'info',
        title: 'Firestore Demo Dataset Restored',
        detail: 'Reset 30 voluntary donors and 5 active emergency hospital requests.',
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'requests');
    }
  }, [pushToast, requireSignedIn]);

  return (
    <RedRelayContext.Provider
      value={{
        user,
        authReady,
        firestoreConnected,
        privateProfile,
        donors,
        requests,
        responses,
        smsLogs,
        activeDonorId,
        nowMs,
        toasts,
        signInWithGoogle,
        signOutUser,
        setActiveDonorId,
        dismissToast,
        pushToast,
        createSosRequest,
        commitToRequest,
        markBloodReceived,
        advanceRequestStatus,
        dispatchSmsBroadcast,
        registerDonor,
        toggleDonorAvailability,
        getEligibleDonorsForRequest,
        resetDemoData,
      }}
    >
      {children}
    </RedRelayContext.Provider>
  );
}

export function useRedRelay() {
  const ctx = useContext(RedRelayContext);
  if (!ctx) {
    throw new Error('useRedRelay must be used within RedRelayProvider');
  }
  return ctx;
}
