import type { BloodGroup } from '../types/redrelay';

export interface CertificateDetails {
  donorName: string;
  donorInitials: string;
  bloodGroup: BloodGroup;
  hospitalName: string;
  city: string;
  requestId: string;
  donatedAt: string;
  certificateId: string;
}

/**
 * Renders a high-resolution (1200x675) Digital Donor Appreciation Certificate
 * onto an offscreen canvas and returns a PNG data URL.
 */
export function renderCertificateDataUrl(details: CertificateDetails): string {
  const canvas = document.createElement('canvas');
  canvas.width = 1200;
  canvas.height = 675;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Clean clinical porcelain background
  ctx.fillStyle = '#F8FAFC';
  ctx.fillRect(0, 0, 1200, 675);

  // Inner white card surface
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(40, 40, 1120, 595);

  // Subtle architectural outer hairline border
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 2;
  ctx.strokeRect(40, 40, 1120, 595);

  // Top surgical crimson accent rule
  ctx.fillStyle = '#DC2626';
  ctx.fillRect(40, 40, 1120, 10);

  // Brand header
  ctx.fillStyle = '#0F172A';
  ctx.font = '700 28px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('RedRelay: LifeLine', 96, 114);

  ctx.fillStyle = '#64748B';
  ctx.font = '500 16px "JetBrains Mono", monospace';
  ctx.fillText(`CERT ID: ${details.certificateId}`, 860, 112);

  // Divider
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(96, 140);
  ctx.lineTo(1104, 140);
  ctx.stroke();

  // Certificate headline
  ctx.fillStyle = '#DC2626';
  ctx.font = '600 15px "JetBrains Mono", monospace';
  ctx.fillText('VOLUNTARY EMERGENCY BLOOD DONATION RECOGNITION', 96, 192);

  ctx.fillStyle = '#0F172A';
  ctx.font = '700 44px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('Certificate of Life-Saving Service', 96, 248);

  // Body copy
  ctx.fillStyle = '#475569';
  ctx.font = '400 21px "DM Sans", sans-serif';
  ctx.fillText('Presented with gratitude to voluntary donor', 96, 304);

  // Donor Name
  ctx.fillStyle = '#0F172A';
  ctx.font = '700 40px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(details.donorName, 96, 360);

  // Supporting message
  ctx.fillStyle = '#334155';
  ctx.font = '400 20px "DM Sans", sans-serif';
  ctx.fillText(
    `for responding to emergency request ${details.requestId} at`,
    96,
    412
  );
  ctx.font = '600 22px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = '#0F172A';
  ctx.fillText(`${details.hospitalName} (${details.city})`, 96, 446);

  // Blood Group Square Seal on right
  ctx.fillStyle = '#FEF2F2';
  ctx.fillRect(910, 210, 194, 194);
  ctx.strokeStyle = '#FECACA';
  ctx.lineWidth = 2;
  ctx.strokeRect(910, 210, 194, 194);

  ctx.fillStyle = '#DC2626';
  ctx.font = '700 64px "JetBrains Mono", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(details.bloodGroup, 1007, 314);

  ctx.fillStyle = '#991B1B';
  ctx.font = '600 14px "DM Sans", sans-serif';
  ctx.fillText('VERIFIED BLOOD UNIT', 1007, 358);
  ctx.textAlign = 'left';

  // Footer metadata row
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(96, 512);
  ctx.lineTo(1104, 512);
  ctx.stroke();

  const formattedDate = new Date(details.donatedAt).toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  ctx.fillStyle = '#64748B';
  ctx.font = '500 14px "DM Sans", sans-serif';
  ctx.fillText('DATE OF FULFILLMENT', 96, 548);
  ctx.fillText('CLINICAL SAFETY', 440, 548);
  ctx.fillText('PRIVACY RELAY', 820, 548);

  ctx.fillStyle = '#0F172A';
  ctx.font = '600 18px "JetBrains Mono", monospace';
  ctx.fillText(formattedDate, 96, 578);
  ctx.fillText('90-Day Recovery Active', 440, 578);
  ctx.fillText(`Donor ${details.donorInitials}`, 820, 578);

  return canvas.toDataURL('image/png');
}

export function downloadCertificatePng(details: CertificateDetails): void {
  const dataUrl = renderCertificateDataUrl(details);
  if (!dataUrl) return;
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = `RedRelay-Certificate-${details.requestId}-${details.bloodGroup}.png`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
