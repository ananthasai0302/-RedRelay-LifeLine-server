import type { BloodGroup, Donor } from '../types/redrelay';

export const BLOOD_GROUPS: BloodGroup[] = [
  'O-',
  'O+',
  'A-',
  'A+',
  'B-',
  'B+',
  'AB-',
  'AB+',
];

/**
 * Clinical ABO/Rh Red Blood Cell Compatibility Matrix.
 * Maps a recipient blood group -> list of biologically compatible donor blood groups.
 */
export const COMPATIBLE_DONORS_FOR_RECIPIENT: Record<BloodGroup, BloodGroup[]> = {
  'O-': ['O-'],
  'O+': ['O+', 'O-'],
  'A-': ['A-', 'O-'],
  'A+': ['A+', 'A-', 'O+', 'O-'],
  'B-': ['B-', 'O-'],
  'B+': ['B+', 'B-', 'O+', 'O-'],
  'AB-': ['AB-', 'A-', 'B-', 'O-'],
  'AB+': ['AB+', 'AB-', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-'],
};

/**
 * Inverse lookup: maps a donor blood group -> list of recipient blood groups they can donate to.
 */
export const COMPATIBLE_RECIPIENTS_FOR_DONOR: Record<BloodGroup, BloodGroup[]> = {
  'O-': ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'],
  'O+': ['O+', 'A+', 'B+', 'AB+'],
  'A-': ['A-', 'A+', 'AB-', 'AB+'],
  'A+': ['A+', 'AB+'],
  'B-': ['B-', 'B+', 'AB-', 'AB+'],
  'B+': ['B+', 'AB+'],
  'AB-': ['AB-', 'AB+'],
  'AB+': ['AB+'],
};

export const RECOVERY_LOCK_DAYS = 90;
const MS_PER_DAY = 24 * 60 * 60 * 1000;

export function isCompatibleDonor(
  donorGroup: BloodGroup,
  recipientGroup: BloodGroup
): boolean {
  return COMPATIBLE_DONORS_FOR_RECIPIENT[recipientGroup].includes(donorGroup);
}

/**
 * Computes great-circle distance in kilometers between two coordinates.
 */
export function haversineDistanceKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

/**
 * Estimates urban emergency driving transit time in minutes.
 */
export function estimateDriveMinutes(distanceKm: number): number {
  if (distanceKm <= 0.5) return 4;
  // Average urban speed ~22 km/h + 3 min dispatch/parking buffer
  return Math.max(5, Math.round((distanceKm / 22) * 60 + 3));
}

/**
 * Masks any raw phone input so personal phone numbers are never stored or leaked publicly.
 */
export function maskPhoneNumber(rawPhone: string): string {
  const digits = rawPhone.replace(/\D/g, '');
  const lastThree = digits.slice(-3) || '409';
  if (digits.length >= 10) {
    return `+91 ••••• ••${lastThree}`;
  }
  return `••• ••• •${lastThree}`;
}

export function extractInitials(fullName: string): string {
  const parts = fullName
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (parts.length === 0) return 'D.R.';
  if (parts.length === 1) return `${parts[0][0].toUpperCase()}.`;
  return `${parts[0][0].toUpperCase()}. ${parts[parts.length - 1][0].toUpperCase()}.`;
}

export interface RecoveryStatus {
  isLocked: boolean;
  daysRemaining: number;
  daysElapsed: number;
  unlockDate: string | null;
}

export function getRecoveryStatus(
  donor: Pick<Donor, 'lastDonationDate' | 'lockedUntil'>,
  nowMs: number = Date.now()
): RecoveryStatus {
  if (!donor.lockedUntil) {
    return {
      isLocked: false,
      daysRemaining: 0,
      daysElapsed: RECOVERY_LOCK_DAYS,
      unlockDate: null,
    };
  }
  const unlockMs = new Date(donor.lockedUntil).getTime();
  if (Number.isNaN(unlockMs) || unlockMs <= nowMs) {
    return {
      isLocked: false,
      daysRemaining: 0,
      daysElapsed: RECOVERY_LOCK_DAYS,
      unlockDate: null,
    };
  }
  const daysRemaining = Math.ceil((unlockMs - nowMs) / MS_PER_DAY);
  const daysElapsed = Math.max(0, RECOVERY_LOCK_DAYS - daysRemaining);
  return {
    isLocked: true,
    daysRemaining,
    daysElapsed,
    unlockDate: donor.lockedUntil,
  };
}

export function formatCountdown(expiresAt: string, nowMs: number): {
  label: string;
  isExpired: boolean;
  isUrgentSoon: boolean;
} {
  const diffMs = new Date(expiresAt).getTime() - nowMs;
  if (diffMs <= 0) {
    return { label: 'Expired', isExpired: true, isUrgentSoon: false };
  }
  const totalMinutes = Math.floor(diffMs / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const label = hours > 0 ? `${hours}h ${String(minutes).padStart(2, '0')}m left` : `${minutes}m left`;
  return {
    label,
    isExpired: false,
    isUrgentSoon: hours < 3,
  };
}
