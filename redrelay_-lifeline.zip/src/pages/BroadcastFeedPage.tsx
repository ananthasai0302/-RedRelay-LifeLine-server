import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  MapPin,
  Radio,
  Send,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { useRedRelay } from '../context/RedRelayContext';
import type { BloodGroup } from '../types/redrelay';
import {
  BLOOD_GROUPS,
  COMPATIBLE_DONORS_FOR_RECIPIENT,
  formatCountdown,
} from '../utils/compatibility';
import { CITIES } from '../data/seedData';
import { LifecycleTracking } from '../components/LifecycleTracking';
import { HospitalRoutingMap } from '../components/HospitalRoutingMap';

type StatusFilter = 'active' | 'all' | 'closed';

export function BroadcastFeedPage() {
  const {
    requests,
    donors,
    responses,
    smsLogs,
    nowMs,
    getEligibleDonorsForRequest,
    commitToRequest,
    markBloodReceived,
    dispatchSmsBroadcast,
  } = useRedRelay();

  const [statusFilter, setStatusFilter] = useState<StatusFilter>('active');
  const [cityFilter, setCityFilter] = useState<string>('All');
  const [bloodFilter, setBloodFilter] = useState<BloodGroup | 'All'>('All');
  const [radiusKm, setRadiusKm] = useState<number>(25);
  const [expandedId, setExpandedId] = useState<string | null>('SOS-4091');

  const filteredRequests = useMemo(() => {
    return requests.filter((req) => {
      const countdown = formatCountdown(req.expiresAt, nowMs);
      const isEffectivelyClosed = req.status === 'Closed' || countdown.isExpired;

      if (statusFilter === 'active' && isEffectivelyClosed) return false;
      if (statusFilter === 'closed' && !isEffectivelyClosed) return false;
      if (cityFilter !== 'All' && req.city !== cityFilter) return false;
      if (bloodFilter !== 'All' && req.bloodGroup !== bloodFilter) return false;
      return true;
    });
  }, [requests, statusFilter, cityFilter, bloodFilter, nowMs]);

  const metrics = useMemo(() => {
    const activeReqs = requests.filter(
      (r) => r.status !== 'Closed' && !formatCountdown(r.expiresAt, nowMs).isExpired
    );
    const totalUnitsNeeded = activeReqs.reduce((acc, r) => acc + r.unitsNeeded, 0);
    const totalUnitsCommitted = activeReqs.reduce(
      (acc, r) => acc + r.unitsCommitted,
      0
    );
    const availableDonors = donors.filter((d) => d.isAvailable && !d.lockedUntil).length;
    const closedCount = requests.filter((r) => r.status === 'Closed').length;
    return {
      activeCount: activeReqs.length,
      totalUnitsNeeded,
      totalUnitsCommitted,
      availableDonors,
      closedCount,
    };
  }, [requests, donors, nowMs]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Hero / Command Header */}
      <section className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
        <div className="max-w-2xl">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
            Emergency Blood Broadcast Feed
          </h1>
          <p className="mt-2 text-sm sm:text-base text-slate-600 leading-relaxed">
            Verified hospital blood requests matched in real time with biologically
            compatible voluntary donors. Donor phone numbers remain masked behind
            private in-app relays.
          </p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <Link
            to="/donor-portal"
            className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
          >
            Switch to Donor View
          </Link>
          <Link
            to="/post-sos"
            className="px-4 py-2 text-sm font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 transition-colors whitespace-nowrap"
          >
            Post Emergency SOS
          </Link>
        </div>
      </section>

      {/* 4-Column KPI Strip (single elevation, flat hairline borders) */}
      <section className="grid grid-cols-2 lg:grid-cols-4 bg-white border border-slate-200 rounded-xl divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
        <div className="p-4 sm:p-5">
          <p className="text-xs font-medium text-slate-500">Active SOS Requests</p>
          <p className="mt-1.5 text-2xl font-bold text-slate-950 font-mono-tabular">
            {metrics.activeCount}
          </p>
          <p className="mt-1 text-xs text-slate-500">Auto-expiring urgency guard</p>
        </div>
        <div className="p-4 sm:p-5">
          <p className="text-xs font-medium text-slate-500">Units Committed / Needed</p>
          <p className="mt-1.5 text-2xl font-bold text-red-600 font-mono-tabular">
            {metrics.totalUnitsCommitted} / {metrics.totalUnitsNeeded}
          </p>
          <p className="mt-1 text-xs text-slate-500">Across active hospital requests</p>
        </div>
        <div className="p-4 sm:p-5">
          <p className="text-xs font-medium text-slate-500">Eligible Donors Online</p>
          <p className="mt-1.5 text-2xl font-bold text-emerald-700 font-mono-tabular">
            {metrics.availableDonors} / {donors.length}
          </p>
          <p className="mt-1 text-xs text-slate-500">90-day clinical recovery enforced</p>
        </div>
        <div className="p-4 sm:p-5">
          <p className="text-xs font-medium text-slate-500">Requests Closed</p>
          <p className="mt-1.5 text-2xl font-bold text-slate-950 font-mono-tabular">
            {metrics.closedCount}
          </p>
          <p className="mt-1 text-xs text-slate-500">Verified blood received</p>
        </div>
      </section>

      {/* Filter & Proximity Controls Bar */}
      <section className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Status Segmented Tabs */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {(
              [
                { id: 'active', label: 'Active SOS' },
                { id: 'all', label: 'All Requests' },
                { id: 'closed', label: 'Closed' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setStatusFilter(tab.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  statusFilter === tab.id
                    ? 'bg-white text-slate-950 shadow-xs'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Proximity Radius Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-500 whitespace-nowrap">
              Donor Radius:
            </span>
            <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              {[5, 10, 25, 50].map((km) => (
                <button
                  key={km}
                  type="button"
                  onClick={() => setRadiusKm(km)}
                  className={`px-2.5 py-1 text-xs font-mono-tabular font-medium rounded-md transition-colors whitespace-nowrap ${
                    radiusKm === km
                      ? 'bg-white text-slate-950 shadow-xs'
                      : 'text-slate-600 hover:text-slate-950'
                  }`}
                >
                  {km} km
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* City & Blood Group Filters */}
        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Filter by city"
            value={cityFilter}
            onChange={(e) => setCityFilter(e.target.value)}
            className="px-3 py-1.5 text-sm bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
          >
            <option value="All">All Cities</option>
            {CITIES.map((city) => (
              <option key={city} value={city}>
                {city}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter by blood group"
            value={bloodFilter}
            onChange={(e) =>
              setBloodFilter(e.target.value as BloodGroup | 'All')
            }
            className="px-3 py-1.5 text-sm bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
          >
            <option value="All">All Blood Groups</option>
            {BLOOD_GROUPS.map((bg) => (
              <option key={bg} value={bg}>
                {bg} Required
              </option>
            ))}
          </select>
        </div>
      </section>

      {/* Emergency SOS Request Cards */}
      <section className="space-y-4">
        {filteredRequests.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
            <p className="text-base font-semibold text-slate-900">
              No matching emergency requests
            </p>
            <p className="mt-1 text-sm text-slate-600">
              Adjust your city, blood group, or status filters—or broadcast a new
              hospital SOS request.
            </p>
            <div className="mt-5 flex justify-center gap-3">
              <button
                type="button"
                onClick={() => {
                  setStatusFilter('all');
                  setCityFilter('All');
                  setBloodFilter('All');
                }}
                className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50"
              >
                Reset Filters
              </button>
              <Link
                to="/post-sos"
                className="px-4 py-2 text-sm font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700"
              >
                Post Emergency SOS
              </Link>
            </div>
          </div>
        ) : (
          filteredRequests.map((req) => {
            const countdown = formatCountdown(req.expiresAt, nowMs);
            const isClosed = req.status === 'Closed' || countdown.isExpired;
            const isCriticalLive =
              !isClosed &&
              (req.urgencyLevel === 'Critical' ||
                req.status === 'Open / Broadcasted');
            const eligibleDonors = getEligibleDonorsForRequest(req, radiusKm);
            const reqResponses = responses.filter((r) => r.requestId === req.id);
            const reqSmsLogs = smsLogs.filter((s) => s.requestId === req.id);
            const isExpanded = expandedId === req.id;
            const progressPct = Math.min(
              100,
              Math.round((req.unitsCommitted / req.unitsNeeded) * 100)
            );
            const compatibleTypes = COMPATIBLE_DONORS_FOR_RECIPIENT[req.bloodGroup];

            return (
              <article
                key={req.id}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden transition-colors"
              >
                <div className="p-5 sm:p-6 space-y-5">
                  {/* Top Row: Blood Group Block + Hospital & Patient Title + Units Progress */}
                  <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-5">
                    <div className="flex items-start gap-4 min-w-0">
                      {/* Clinical Blood Group Marker */}
                      <div
                        className={`w-14 h-14 rounded-xl border flex flex-col items-center justify-center shrink-0 ${
                          isClosed
                            ? 'bg-slate-100 border-slate-200 text-slate-600'
                            : 'bg-red-50 border-red-200 text-red-700'
                        }`}
                      >
                        <span className="text-lg font-bold font-mono-tabular leading-none">
                          {req.bloodGroup}
                        </span>
                        <span className="text-[10px] font-medium uppercase tracking-wide mt-1">
                          Group
                        </span>
                      </div>

                      <div className="min-w-0 space-y-1">
                        {/* Primary Title */}
                        <div className="flex flex-wrap items-center gap-2.5">
                          {isCriticalLive && (
                            <span
                              className="relative flex h-2.5 w-2.5 shrink-0"
                              title="Live active SOS broadcast"
                            >
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75" />
                              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-600" />
                            </span>
                          )}
                          <h2 className="text-lg font-bold text-slate-950 truncate">
                            {req.hospitalName}
                          </h2>
                          <span
                            className={`text-xs font-semibold ${
                              isClosed
                                ? 'text-slate-500'
                                : req.urgencyLevel === 'Critical'
                                ? 'text-red-600'
                                : 'text-amber-700'
                            }`}
                          >
                            {isClosed ? 'Closed' : `${req.urgencyLevel} Priority`}
                          </span>
                        </div>

                        {/* Unboxed Metadata with typographic separators */}
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs sm:text-sm text-slate-600">
                          <span className="font-mono-tabular font-medium text-slate-800">
                            {req.id}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="font-medium text-slate-800">
                            {req.bloodKind}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>Patient: {req.patientName}</span>
                          <span aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-slate-400" />
                            {req.locality}, {req.city}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500">
                          <span className="inline-flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                            Verified: {req.doctorContact}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>
                            Compatible Donors: {compatibleTypes.join(', ')}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Right Metric Column: Units Counter & Expiration Countdown */}
                    <div className="flex sm:flex-row lg:flex-col items-start sm:items-center lg:items-end justify-between gap-3 shrink-0 lg:text-right">
                      <div className="w-full sm:w-52">
                        <div className="flex items-baseline justify-between text-xs mb-1.5">
                          <span className="font-medium text-slate-600">
                            Units Committed
                          </span>
                          <span className="font-mono-tabular font-bold text-slate-950">
                            {req.unitsCommitted} / {req.unitsNeeded} Units
                          </span>
                        </div>
                        <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all duration-300 ${
                              req.unitsCommitted >= req.unitsNeeded
                                ? 'bg-emerald-600'
                                : 'bg-red-600'
                            }`}
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 text-xs font-mono-tabular">
                        <Clock
                          className={`w-3.5 h-3.5 ${
                            countdown.isExpired
                              ? 'text-slate-400'
                              : countdown.isUrgentSoon
                              ? 'text-red-600'
                              : 'text-slate-500'
                          }`}
                        />
                        <span
                          className={
                            countdown.isExpired
                              ? 'text-slate-500'
                              : countdown.isUrgentSoon
                              ? 'text-red-600 font-semibold'
                              : 'text-slate-700'
                          }
                        >
                          {isClosed ? 'Request Resolved' : countdown.label}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Live Interactive 4-Stage Request Lifecycle Tracking */}
                  <LifecycleTracking
                    request={req}
                    isExpired={countdown.isExpired}
                  />

                  {/* Action Bar */}
                  <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100">
                    <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-600">
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedId(isExpanded ? null : req.id)
                        }
                        className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200/80 rounded-lg transition-colors"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>
                          {eligibleDonors.length} Compatible Donor(s) within{' '}
                          {radiusKm} km
                        </span>
                        {isExpanded ? (
                          <ChevronUp className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5" />
                        )}
                      </button>

                      {!isClosed && (
                        <button
                          type="button"
                          onClick={() => dispatchSmsBroadcast(req.id, radiusKm)}
                          className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
                        >
                          <Send className="w-3.5 h-3.5 text-slate-500" />
                          Simulate SMS SOS Alert
                        </button>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2.5">
                      {!isClosed && (
                        <button
                          type="button"
                          onClick={() => markBloodReceived(req.id)}
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 transition-colors"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Mark Blood Received
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Expandable Inspector: Matched Donors + Leaflet Routing Map + SMS Log */}
                {isExpanded && (
                  <div className="border-t border-slate-200 bg-slate-50/60 p-5 sm:p-6">
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                      {/* Left: Eligible Donors & Committed Responses */}
                      <div className="lg:col-span-6 space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="text-sm font-bold text-slate-900">
                            Privacy-Masked Compatible Donor Pool ({radiusKm} km)
                          </h3>
                          <span className="text-xs text-slate-500">
                            Phones masked via relay
                          </span>
                        </div>

                        {reqResponses.length > 0 && (
                          <div className="space-y-2">
                            <p className="text-xs font-semibold text-emerald-800">
                              Committed Donors ({reqResponses.length})
                            </p>
                            <div className="bg-white border border-emerald-200 rounded-lg divide-y divide-emerald-100">
                              {reqResponses.map((resp) => (
                                <div
                                  key={resp.id}
                                  className="px-3.5 py-2.5 flex items-center justify-between gap-3 text-xs"
                                >
                                  <div className="min-w-0">
                                    <span className="font-semibold text-slate-900">
                                      Donor {resp.donorInitials}
                                    </span>
                                    <span className="mx-1.5 text-slate-400">·</span>
                                    <span className="font-mono-tabular font-semibold text-emerald-700">
                                      {resp.donorBloodGroup}
                                    </span>
                                    <span className="mx-1.5 text-slate-400">·</span>
                                    <span className="text-slate-600">
                                      {resp.donorLocality}
                                    </span>
                                  </div>
                                  <div className="font-mono-tabular text-emerald-800 font-medium shrink-0">
                                    {resp.distanceKm} km · ~{resp.etaMinutes}m ·{' '}
                                    {resp.status}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {eligibleDonors.length === 0 ? (
                          <div className="bg-white border border-slate-200 rounded-lg p-4 text-xs text-slate-600">
                            No available compatible donors found within {radiusKm}{' '}
                            km. Try expanding the proximity radius above.
                          </div>
                        ) : (
                          <div className="bg-white border border-slate-200 rounded-lg divide-y divide-slate-100 max-h-72 overflow-y-auto">
                            {eligibleDonors.map((donor) => {
                              const hasCommitted = reqResponses.some(
                                (r) => r.donorId === donor.id
                              );
                              return (
                                <div
                                  key={donor.id}
                                  className="px-3.5 py-2.5 flex items-center justify-between gap-3"
                                >
                                  <div className="min-w-0">
                                    <div className="flex items-center gap-2 text-sm">
                                      <span className="font-semibold text-slate-900">
                                        {donor.initials}
                                      </span>
                                      <span className="font-mono-tabular text-xs font-bold text-red-700">
                                        {donor.bloodGroup}
                                      </span>
                                      <span className="text-xs text-slate-500 truncate">
                                        {donor.locality}
                                      </span>
                                    </div>
                                    <div className="text-xs text-slate-500 font-mono-tabular mt-0.5">
                                      {donor.maskedPhone} · {donor.distanceKm} km · ~
                                      {donor.etaMinutes} min drive
                                    </div>
                                  </div>

                                  {!isClosed && (
                                    <button
                                      type="button"
                                      disabled={hasCommitted}
                                      onClick={() =>
                                        commitToRequest(req.id, donor.id)
                                      }
                                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                                        hasCommitted
                                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 cursor-default'
                                          : 'bg-slate-900 text-white hover:bg-red-600'
                                      }`}
                                    >
                                      {hasCommitted
                                        ? 'Unit Committed'
                                        : 'I Can Donate'}
                                    </button>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {/* Recent Simulated SMS Dispatch Logs for this Request */}
                        {reqSmsLogs.length > 0 && (
                          <div className="space-y-1.5">
                            <p className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                              <Radio className="w-3.5 h-3.5 text-red-600" />
                              SMS SOS Dispatch Log ({reqSmsLogs.length} sent)
                            </p>
                            <div className="bg-white border border-slate-200 rounded-lg divide-y divide-slate-100 max-h-36 overflow-y-auto">
                              {reqSmsLogs.slice(0, 5).map((log) => (
                                <div
                                  key={log.id}
                                  className="px-3 py-2 text-xs flex items-center justify-between gap-2"
                                >
                                  <span className="text-slate-700 truncate">
                                    To {log.donorInitials} ({log.donorBloodGroup}) ·{' '}
                                    <span className="font-mono-tabular">
                                      {log.maskedPhone}
                                    </span>
                                  </span>
                                  <span className="font-mono-tabular text-emerald-700 shrink-0">
                                    {log.deliveryStatus} · {log.distanceKm} km
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Right: Interactive Hospital Routing Map */}
                      <div className="lg:col-span-6 space-y-2">
                        <div className="flex items-center justify-between">
                          <h3 className="text-sm font-bold text-slate-900">
                            Hospital Routing & Donor Proximity Map
                          </h3>
                          <Link
                            to="/dispatch"
                            className="text-xs font-medium text-red-600 hover:underline"
                          >
                            Open Full Dispatch Console
                          </Link>
                        </div>
                        <HospitalRoutingMap
                          request={req}
                          eligibleDonors={eligibleDonors}
                          responses={responses}
                          radiusKm={radiusKm}
                          heightClass="h-80"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </article>
            );
          })
        )}
      </section>
    </div>
  );
}
