import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  Check,
  Lock,
  LogIn,
  Radio,
  ShieldCheck,
} from 'lucide-react';
import { BLOOD_KINDS, CITIES, HOSPITALS, LOCALITIES } from '../data/seedData';
import { useRedRelay } from '../context/RedRelayContext';
import type { BloodGroup, BloodKind, UrgencyLevel } from '../types/redrelay';
import {
  BLOOD_GROUPS,
  COMPATIBLE_DONORS_FOR_RECIPIENT,
  estimateDriveMinutes,
  getRecoveryStatus,
  haversineDistanceKm,
  isCompatibleDonor,
  RECOVERY_LOCK_DAYS,
} from '../utils/compatibility';
import {
  SearchableDropdown,
  type SearchableDropdownOption,
} from '../components/SearchableDropdown';

const SEARCH_RADIUS_KM = 25;

export function PostSosPage() {
  const navigate = useNavigate();
  const { donors, user, signInWithGoogle, createSosRequest, nowMs } =
    useRedRelay();

  const [patientName, setPatientName] = useState('');
  const [hospitalId, setHospitalId] = useState(HOSPITALS[0].id);
  const [customHospitalName, setCustomHospitalName] = useState('');
  const [customCity, setCustomCity] = useState<string>('Hyderabad, Telangana');
  const [customLocality, setCustomLocality] = useState<string>('Jubilee Hills');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('B+');
  const [bloodKind, setBloodKind] = useState<BloodKind>('Whole Blood');
  const [unitsNeeded, setUnitsNeeded] = useState<number>(2);
  const [deadlineHours, setDeadlineHours] = useState<number>(4);
  const [doctorContact, setDoctorContact] = useState('');
  const [clinicalNotes, setClinicalNotes] = useState('');
  const [enforceRecoveryPolicy, setEnforceRecoveryPolicy] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const isCustomHospital = hospitalId === 'custom';

  const customCityLocalities = useMemo(
    () => LOCALITIES.filter((l) => l.city === customCity),
    [customCity]
  );

  const selectedLocation = useMemo(() => {
    if (isCustomHospital) {
      const loc =
        LOCALITIES.find(
          (l) => l.city === customCity && l.locality === customLocality
        ) ?? LOCALITIES[0];
      return {
        name: customHospitalName.trim() || 'Custom Hospital',
        city: loc.city,
        locality: loc.locality,
        lat: loc.lat,
        lng: loc.lng,
      };
    }
    const h = HOSPITALS.find((item) => item.id === hospitalId) ?? HOSPITALS[0];
    return {
      name: h.name,
      city: h.city,
      locality: h.locality,
      lat: h.lat,
      lng: h.lng,
    };
  }, [
    isCustomHospital,
    hospitalId,
    customCity,
    customLocality,
    customHospitalName,
  ]);

  // Searchable dropdown options for 'Target Hospital' with 90-day recovery policy metrics
  const hospitalOptions: SearchableDropdownOption[] = useMemo(() => {
    const presetOptions: SearchableDropdownOption[] = HOSPITALS.map((h) => {
      let unlockedNearby = 0;
      let lockedNearby = 0;

      for (const donor of donors) {
        const dist = haversineDistanceKm(h.lat, h.lng, donor.lat, donor.lng);
        if (dist > SEARCH_RADIUS_KM) continue;
        const recovery = getRecoveryStatus(donor, nowMs);
        if (recovery.isLocked) {
          lockedNearby += 1;
        } else if (donor.isAvailable) {
          unlockedNearby += 1;
        }
      }

      return {
        value: h.id,
        label: h.name,
        sublabel: `${h.locality}, ${h.city}`,
        metricText:
          lockedNearby > 0
            ? `${unlockedNearby} unlocked · ${lockedNearby} locked (90d)`
            : `${unlockedNearby} unlocked`,
        metricTone: unlockedNearby > 0 ? 'positive' : 'warning',
        searchKeywords: `${h.name} ${h.locality} ${h.city} ${h.address}`,
        isEligible: unlockedNearby > 0,
      };
    });

    presetOptions.push({
      value: 'custom',
      label: 'Other / Specify Custom Hospital Name',
      sublabel: 'Enter custom hospital, city, and locality',
      metricText: 'Manual entry',
      metricTone: 'muted',
      searchKeywords: 'custom other manual hospital',
      isEligible: true,
    });

    return presetOptions;
  }, [donors, nowMs]);

  // Searchable dropdown options for 'Required Blood Group' filtered by 90-day recovery policy
  const bloodGroupOptions: SearchableDropdownOption[] = useMemo(() => {
    return BLOOD_GROUPS.map((bg) => {
      let unlockedCompatible = 0;
      let lockedCompatible = 0;

      for (const donor of donors) {
        if (!isCompatibleDonor(donor.bloodGroup, bg)) continue;
        const dist = haversineDistanceKm(
          selectedLocation.lat,
          selectedLocation.lng,
          donor.lat,
          donor.lng
        );
        if (dist > SEARCH_RADIUS_KM) continue;
        const recovery = getRecoveryStatus(donor, nowMs);
        if (recovery.isLocked) {
          lockedCompatible += 1;
        } else if (donor.isAvailable) {
          unlockedCompatible += 1;
        }
      }

      const compatibleList = COMPATIBLE_DONORS_FOR_RECIPIENT[bg].join(', ');
      const universalTag =
        bg === 'O-'
          ? 'Universal Donor'
          : bg === 'AB+'
          ? 'Universal Recipient'
          : '';

      return {
        value: bg,
        label: universalTag ? `${bg} (${universalTag})` : bg,
        sublabel: `Compatible donors: ${compatibleList}`,
        metricText:
          lockedCompatible > 0
            ? `${unlockedCompatible} ready · ${lockedCompatible} in 90d lock`
            : `${unlockedCompatible} ready (25 km)`,
        metricTone: unlockedCompatible > 0 ? 'positive' : 'warning',
        searchKeywords: `${bg} ${compatibleList} ${universalTag}`,
        isEligible: unlockedCompatible > 0,
      };
    });
  }, [donors, selectedLocation.lat, selectedLocation.lng, nowMs]);

  const urgencyLevel: UrgencyLevel =
    deadlineHours <= 4 ? 'Critical' : deadlineHours <= 8 ? 'Urgent' : 'Standard';

  const compatibleGroups = COMPATIBLE_DONORS_FOR_RECIPIENT[bloodGroup];

  const { previewMatchedDonors, lockedCompatibleDonors } = useMemo(() => {
    const matched: Array<
      (typeof donors)[number] & { distanceKm: number; etaMinutes: number }
    > = [];
    const locked: Array<
      (typeof donors)[number] & { distanceKm: number; daysRemaining: number }
    > = [];

    for (const donor of donors) {
      if (!isCompatibleDonor(donor.bloodGroup, bloodGroup)) continue;
      const distanceKm = haversineDistanceKm(
        selectedLocation.lat,
        selectedLocation.lng,
        donor.lat,
        donor.lng
      );
      if (distanceKm > SEARCH_RADIUS_KM) continue;

      const recovery = getRecoveryStatus(donor, nowMs);
      if (recovery.isLocked) {
        locked.push({
          ...donor,
          distanceKm,
          daysRemaining: recovery.daysRemaining,
        });
      } else if (donor.isAvailable) {
        matched.push({
          ...donor,
          distanceKm,
          etaMinutes: estimateDriveMinutes(distanceKm),
        });
      }
    }

    matched.sort((a, b) => a.distanceKm - b.distanceKm);
    locked.sort((a, b) => a.distanceKm - b.distanceKm);

    return {
      previewMatchedDonors: matched,
      lockedCompatibleDonors: locked,
    };
  }, [donors, bloodGroup, selectedLocation, nowMs]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setErrorMsg(
        'Please sign in with Google before broadcasting a verified SOS request.'
      );
      return;
    }
    if (!patientName.trim()) {
      setErrorMsg('Please enter the patient name or case reference.');
      return;
    }
    if (isCustomHospital && !customHospitalName.trim()) {
      setErrorMsg('Please specify which target hospital the receiver is admitted to.');
      return;
    }
    if (!doctorContact.trim()) {
      setErrorMsg(
        'Doctor or blood bank verification contact is required to prevent unverified broadcasts.'
      );
      return;
    }

    setErrorMsg('');
    setSubmitting(true);
    try {
      const result = await createSosRequest({
        patientName,
        hospitalId,
        customHospitalName,
        customCity,
        customLocality,
        bloodGroup,
        bloodKind,
        unitsNeeded,
        urgencyLevel,
        deadlineHours,
        doctorContact,
        clinicalNotes,
      });
      if (result) {
        navigate('/');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div className="max-w-2xl">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
            Post Emergency Blood SOS
          </h1>
          <p className="mt-2 text-sm sm:text-base text-slate-600 leading-relaxed">
            Search and select a Target Hospital and Required Blood Group
            filtered dynamically against the {RECOVERY_LOCK_DAYS}-day donor
            recovery policy. Verified requests auto-expire at the deadline.
          </p>
        </div>

        <label className="inline-flex items-center gap-2.5 px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800 cursor-pointer select-none shrink-0">
          <input
            type="checkbox"
            checked={enforceRecoveryPolicy}
            onChange={(e) => setEnforceRecoveryPolicy(e.target.checked)}
            className="rounded border-slate-300 text-red-600 focus:ring-red-500"
          />
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            Filter dropdowns by {RECOVERY_LOCK_DAYS}-day recovery policy
          </span>
        </label>
      </div>

      {!user && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs sm:text-sm text-amber-900">
            Google Sign-In is required to publish verified emergency requests to
            Cloud Firestore.
          </p>
          <button
            type="button"
            onClick={() => void signInWithGoogle()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800"
          >
            <LogIn className="w-3.5 h-3.5" />
            Sign In with Google
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-6"
        >
          {errorMsg && (
            <div className="flex items-start gap-2.5 p-3.5 rounded-lg bg-red-50 border border-red-200 text-xs sm:text-sm text-red-800">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Section 1: Receiver & Target Hospital */}
          <fieldset className="space-y-4">
            <legend className="text-sm font-bold text-slate-950 pb-2 border-b border-slate-100 w-full">
              01. Receiver &amp; Target Hospital
            </legend>

            <div>
              <label
                htmlFor="patient-name"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Receiver / Patient Name or Clinical Case Reference
              </label>
              <input
                id="patient-name"
                type="text"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                placeholder="e.g., Arjun M. — Emergency Trauma OT"
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
              />
            </div>

            <SearchableDropdown
              id="target-hospital-dropdown"
              label="Target Hospital"
              value={hospitalId}
              onChange={(nextId) => setHospitalId(nextId)}
              options={hospitalOptions}
              placeholder="Search target hospital or city..."
              searchPlaceholder="Search by hospital name, locality, or city..."
              emptyText="No hospitals have unlocked donors within 25 km."
              policyFilterLabel="Only hospitals with unlocked donors (90d policy)"
              policyFilterActive={enforceRecoveryPolicy}
              onTogglePolicyFilter={setEnforceRecoveryPolicy}
              helperText="25 km donor pool evaluated"
            />

            {isCustomHospital && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="sm:col-span-3">
                  <label
                    htmlFor="custom-hospital-name"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Custom Target Hospital Name
                  </label>
                  <input
                    id="custom-hospital-name"
                    type="text"
                    value={customHospitalName}
                    onChange={(e) => setCustomHospitalName(e.target.value)}
                    placeholder="e.g., NIMS Hospital, Punjagutta"
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label
                    htmlFor="custom-city"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    City
                  </label>
                  <select
                    id="custom-city"
                    value={customCity}
                    onChange={(e) => {
                      const next = e.target.value;
                      setCustomCity(next);
                      const first = LOCALITIES.find((l) => l.city === next);
                      if (first) setCustomLocality(first.locality);
                    }}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg"
                  >
                    {CITIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label
                    htmlFor="custom-locality"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Locality
                  </label>
                  <select
                    id="custom-locality"
                    value={customLocality}
                    onChange={(e) => setCustomLocality(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg"
                  >
                    {customCityLocalities.map((l) => (
                      <option key={l.locality} value={l.locality}>
                        {l.locality}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}
          </fieldset>

          {/* Section 2: Required Blood Group & Component */}
          <fieldset className="space-y-4">
            <legend className="text-sm font-bold text-slate-950 pb-2 border-b border-slate-100 w-full">
              02. Required Blood Group &amp; Component
            </legend>

            <SearchableDropdown
              id="required-blood-group-dropdown"
              label="Required Blood Group"
              value={bloodGroup}
              onChange={(nextBg) => setBloodGroup(nextBg as BloodGroup)}
              options={bloodGroupOptions}
              placeholder="Search blood group (e.g., O-, B+, AB+)..."
              searchPlaceholder="Filter blood group or compatible donor group..."
              emptyText="No blood groups currently have unlocked compatible donors within 25 km."
              policyFilterLabel="Hide groups with 0 unlocked donors (90d policy)"
              policyFilterActive={enforceRecoveryPolicy}
              onTogglePolicyFilter={setEnforceRecoveryPolicy}
              helperText={`Around ${selectedLocation.locality}`}
            />

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-1">
                <label
                  htmlFor="blood-kind-select"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Blood Component Kind
                </label>
                <select
                  id="blood-kind-select"
                  value={bloodKind}
                  onChange={(e) => setBloodKind(e.target.value as BloodKind)}
                  className="w-full px-3 py-2.5 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                >
                  {BLOOD_KINDS.map((kind) => (
                    <option key={kind} value={kind}>
                      {kind}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="units-needed"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Units Needed
                </label>
                <select
                  id="units-needed"
                  value={unitsNeeded}
                  onChange={(e) => setUnitsNeeded(Number(e.target.value))}
                  className="w-full px-3 py-2.5 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 font-mono-tabular focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                >
                  {[1, 2, 3, 4, 5, 6].map((u) => (
                    <option key={u} value={u}>
                      {u} {u === 1 ? 'Unit' : 'Units'}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="urgency-deadline"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Urgency Deadline
                </label>
                <select
                  id="urgency-deadline"
                  value={deadlineHours}
                  onChange={(e) => setDeadlineHours(Number(e.target.value))}
                  className="w-full px-3 py-2.5 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                >
                  <option value={2}>Within 2 Hours (Critical)</option>
                  <option value={4}>Within 4 Hours (Critical)</option>
                  <option value={8}>Within 8 Hours (Urgent)</option>
                  <option value={24}>Within 24 Hours (Standard Max)</option>
                </select>
              </div>
            </div>
          </fieldset>

          {/* Section 3: Clinical Verification */}
          <fieldset className="space-y-4">
            <legend className="text-sm font-bold text-slate-950 pb-2 border-b border-slate-100 w-full">
              03. Clinical Verification &amp; Ward Notes
            </legend>

            <div>
              <label
                htmlFor="doctor-contact"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Doctor / Blood Bank Verification Contact
              </label>
              <input
                id="doctor-contact"
                type="text"
                value={doctorContact}
                onChange={(e) => setDoctorContact(e.target.value)}
                placeholder="e.g., Dr. K. Rao · Surgical Duty Desk (#4012)"
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
              />
            </div>

            <div>
              <label
                htmlFor="clinical-notes"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Hospital Ward / Cross-Match Instructions (Optional)
              </label>
              <textarea
                id="clinical-notes"
                rows={2}
                value={clinicalNotes}
                onChange={(e) => setClinicalNotes(e.target.value)}
                placeholder="e.g., Report to Emergency Blood Bank Desk, Ground Floor Gate 2."
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
              />
            </div>
          </fieldset>

          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
            <span className="inline-flex items-center gap-1.5 text-xs text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Auto-expires in {deadlineHours}h to prevent ghost alerts
            </span>
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 disabled:opacity-60 transition-colors"
            >
              <Radio className="w-4 h-4" />
              {submitting ? 'Broadcasting...' : 'Broadcast SOS & Alert Donors'}
            </button>
          </div>
        </form>

        {/* Right: Real-time Clinical Compatibility & 90-Day Recovery Policy Preview */}
        <aside className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div>
            <h2 className="text-base font-bold text-slate-950">
              Live Compatibility &amp; Dispatch Preview
            </h2>
            <p className="mt-1 text-xs text-slate-600">
              Evaluated dynamically around {selectedLocation.name} (
              {selectedLocation.locality}, {selectedLocation.city}).
            </p>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-2.5">
            <div className="flex items-center justify-between text-xs gap-2">
              <span className="font-medium text-slate-600">Target Hospital</span>
              <span className="font-semibold text-slate-900 text-right truncate">
                {selectedLocation.name}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs gap-2">
              <span className="font-medium text-slate-600">
                Required Blood &amp; Kind
              </span>
              <span className="font-mono-tabular font-bold text-red-600 text-sm text-right">
                {bloodGroup} · {bloodKind}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs gap-2">
              <span className="font-medium text-slate-600">
                Eligible Donor Groups
              </span>
              <span className="font-mono-tabular font-semibold text-slate-900 text-right">
                {compatibleGroups.join(' · ')}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-600">
                Unlocked Donors Within {SEARCH_RADIUS_KM} km
              </span>
              <span className="font-mono-tabular font-bold text-emerald-700">
                {previewMatchedDonors.length} donor(s)
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-600">
                Excluded by {RECOVERY_LOCK_DAYS}-Day Lock
              </span>
              <span className="font-mono-tabular font-semibold text-amber-700">
                {lockedCompatibleDonors.length} donor(s)
              </span>
            </div>
          </div>

          <div className="space-y-2.5">
            <p className="text-xs font-semibold text-slate-700">
              Nearest Unlocked Donors Queued for SMS Alert
            </p>
            {previewMatchedDonors.length === 0 ? (
              <p className="text-xs text-slate-500 py-4 border border-dashed border-slate-200 rounded-lg text-center">
                No unlocked compatible donors currently within {SEARCH_RADIUS_KM}{' '}
                km of {selectedLocation.city}.
              </p>
            ) : (
              <div className="border border-slate-200 rounded-lg divide-y divide-slate-100">
                {previewMatchedDonors.slice(0, 5).map((d) => (
                  <div
                    key={d.id}
                    className="px-3.5 py-2.5 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="min-w-0">
                      <span className="font-semibold text-slate-900">
                        {d.initials}
                      </span>
                      <span className="mx-1.5 text-slate-300">·</span>
                      <span className="font-mono-tabular font-bold text-red-700">
                        {d.bloodGroup}
                      </span>
                      <span className="mx-1.5 text-slate-300">·</span>
                      <span className="text-slate-600">{d.locality}</span>
                    </div>
                    <div className="flex items-center gap-2 font-mono-tabular text-slate-600 shrink-0">
                      <span>{d.distanceKm} km</span>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {lockedCompatibleDonors.length > 0 && (
            <div className="space-y-2 pt-1">
              <p className="text-xs font-semibold text-amber-800 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-amber-700" />
                Held Back by {RECOVERY_LOCK_DAYS}-Day Clinical Recovery Policy
              </p>
              <div className="border border-amber-200 bg-amber-50/50 rounded-lg divide-y divide-amber-100">
                {lockedCompatibleDonors.map((d) => (
                  <div
                    key={d.id}
                    className="px-3.5 py-2 flex items-center justify-between gap-2 text-xs text-amber-950"
                  >
                    <div className="min-w-0 truncate">
                      <span className="font-semibold">{d.initials}</span>
                      <span className="mx-1.5 text-amber-400">·</span>
                      <span className="font-mono-tabular font-bold">
                        {d.bloodGroup}
                      </span>
                      <span className="mx-1.5 text-amber-400">·</span>
                      <span>{d.locality}</span>
                    </div>
                    <span className="font-mono-tabular font-semibold text-amber-800 shrink-0">
                      {d.daysRemaining}d cooldown left
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
