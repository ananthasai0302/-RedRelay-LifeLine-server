import { useMemo, useState } from 'react';
import {
  Crosshair,
  ExternalLink,
  Loader2,
  MapPin,
  Navigation,
  Radio,
  Search,
  Send,
} from 'lucide-react';
import { useRedRelay } from '../context/RedRelayContext';
import { HospitalRoutingMap } from '../components/HospitalRoutingMap';
import { LifecycleTracking } from '../components/LifecycleTracking';
import { useUserLocation } from '../hooks/useUserLocation';
import { LOCALITIES } from '../data/seedData';
import type { BloodGroup } from '../types/redrelay';
import {
  BLOOD_GROUPS,
  estimateDriveMinutes,
  formatCountdown,
  haversineDistanceKm,
} from '../utils/compatibility';

interface GroundingPlace {
  title: string;
  uri: string;
  snippets: string[];
}

export function RoutingDispatchPage() {
  const {
    requests,
    responses,
    smsLogs,
    nowMs,
    getEligibleDonorsForRequest,
    dispatchSmsBroadcast,
  } = useRedRelay();

  const { location, refreshGps, setManualLocality } = useUserLocation();

  const activeRequests = useMemo(
    () =>
      requests.filter(
        (r) =>
          r.status !== 'Closed' &&
          !formatCountdown(r.expiresAt, nowMs).isExpired
      ),
    [requests, nowMs]
  );

  const [bloodFilter, setBloodFilter] = useState<BloodGroup | 'All'>('All');
  const [radiusKm, setRadiusKm] = useState<number>(50);
  const [selectedRequestId, setSelectedRequestId] = useState<string>(
    activeRequests[0]?.id ?? requests[0]?.id ?? ''
  );

  // Gemini Maps Grounding state
  const [groundingQuery, setGroundingQuery] = useState(
    '24-hour licensed blood banks and emergency trauma hospitals nearby'
  );
  const [groundingLoading, setGroundingLoading] = useState(false);
  const [groundingError, setGroundingError] = useState('');
  const [groundingText, setGroundingText] = useState('');
  const [groundingPlaces, setGroundingPlaces] = useState<GroundingPlace[]>([]);

  const sortedActiveRequests = useMemo(() => {
    return activeRequests
      .filter((r) => bloodFilter === 'All' || r.bloodGroup === bloodFilter)
      .map((r) => {
        const distanceFromUser = haversineDistanceKm(
          location.lat,
          location.lng,
          r.lat,
          r.lng
        );
        return {
          request: r,
          distanceFromUser,
          etaFromUser: estimateDriveMinutes(distanceFromUser),
        };
      })
      .sort((a, b) => a.distanceFromUser - b.distanceFromUser);
  }, [activeRequests, bloodFilter, location.lat, location.lng]);

  const mapVisibleRequests = useMemo(() => {
    const withinRadius = sortedActiveRequests
      .filter((item) => radiusKm >= 50 || item.distanceFromUser <= radiusKm)
      .map((item) => item.request);
    if (withinRadius.length > 0) return withinRadius;
    return sortedActiveRequests.map((item) => item.request);
  }, [sortedActiveRequests, radiusKm]);

  const selectedRequest = useMemo(
    () =>
      requests.find((r) => r.id === selectedRequestId) ??
      mapVisibleRequests[0] ??
      activeRequests[0] ??
      requests[0],
    [requests, mapVisibleRequests, activeRequests, selectedRequestId]
  );

  const eligibleDonors = useMemo(() => {
    if (!selectedRequest) return [];
    return getEligibleDonorsForRequest(selectedRequest, Math.min(radiusKm, 25));
  }, [selectedRequest, radiusKm, getEligibleDonorsForRequest]);

  const requestSmsLogs = useMemo(() => {
    if (!selectedRequest) return smsLogs;
    return smsLogs.filter((s) => s.requestId === selectedRequest.id);
  }, [smsLogs, selectedRequest]);

  const handleMapsGroundingSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setGroundingLoading(true);
    setGroundingError('');
    try {
      const res = await fetch('/api/maps/grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: groundingQuery,
          latitude: location.lat,
          longitude: location.lng,
        }),
      });
      const data = (await res.json()) as {
        text?: string;
        places?: GroundingPlace[];
        error?: string;
      };
      if (!res.ok) {
        throw new Error(data.error || `Server returned ${res.status}`);
      }
      setGroundingText(data.text || '');
      setGroundingPlaces(data.places || []);
    } catch (err) {
      setGroundingError(
        err instanceof Error ? err.message : 'Unable to fetch Maps Grounding.'
      );
    } finally {
      setGroundingLoading(false);
    }
  };

  if (!selectedRequest) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 text-center text-sm text-slate-600">
        No emergency requests available to route.
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <section className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div className="max-w-2xl">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
            Emergency Map, Routing & SMS Dispatch
          </h1>
          <p className="mt-2 text-sm sm:text-base text-slate-600 leading-relaxed">
            Interactive Leaflet view of all active emergency requests relative to
            your current location with custom blood-type pins, SMS SOS dispatch,
            and Gemini Maps Grounding for nearby blood banks.
          </p>
        </div>

        {/* User Location Control Strip */}
        <div className="bg-white border border-slate-200 rounded-xl p-2.5 flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-1.5 text-xs text-slate-700 px-1">
            <MapPin className="w-3.5 h-3.5 text-blue-600" />
            <span className="font-semibold">
              {location.source === 'gps' ? 'Live GPS:' : 'Hub:'}
            </span>
            <span className="font-mono-tabular text-slate-600">
              {location.lat.toFixed(3)}, {location.lng.toFixed(3)}
            </span>
          </div>

          <button
            type="button"
            onClick={refreshGps}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100 transition-colors"
          >
            <Crosshair className="w-3.5 h-3.5" />
            {location.status === 'locating' ? 'Locating...' : 'Use My GPS'}
          </button>

          <select
            aria-label="Set manual location fallback"
            onChange={(e) => {
              if (e.target.value) setManualLocality(e.target.value);
            }}
            defaultValue=""
            className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700"
          >
            <option value="" disabled>
              Jump to Locality...
            </option>
            {LOCALITIES.map((l) => (
              <option key={`${l.city}-${l.locality}`} value={l.locality}>
                {l.locality}, {l.city}
              </option>
            ))}
          </select>
        </div>
      </section>

      {/* Filter Bar for Blood-Type Icons & Radius */}
      <section className="bg-white border border-slate-200 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-600">
            Filter Map by Blood Type:
          </span>
          <div className="flex flex-wrap items-center gap-1">
            <button
              type="button"
              onClick={() => setBloodFilter('All')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md border transition-colors ${
                bloodFilter === 'All'
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              All ({activeRequests.length})
            </button>
            {BLOOD_GROUPS.map((bg) => (
              <button
                key={bg}
                type="button"
                onClick={() => setBloodFilter(bg)}
                className={`px-2.5 py-1 text-xs font-mono-tabular font-bold rounded-md border transition-colors ${
                  bloodFilter === bg
                    ? 'bg-red-600 text-white border-red-600'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {bg}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-slate-500">Radius:</span>
          <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {[5, 10, 25, 50].map((km) => (
              <button
                key={km}
                type="button"
                onClick={() => setRadiusKm(km)}
                className={`px-2.5 py-1 text-xs font-mono-tabular font-medium rounded-md transition-colors ${
                  radiusKm === km
                    ? 'bg-white text-slate-950 shadow-xs'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                {km === 50 ? '50+ km' : `${km} km`}
              </button>
            ))}
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Interactive Multi-Request Leaflet Map + Sorted SOS List */}
        <section className="lg:col-span-7 space-y-5">
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-bold text-slate-950">
                  Active Emergency Requests Map ({mapVisibleRequests.length} plotted)
                </h2>
                <p className="text-xs text-slate-600">
                  Focused: <span className="font-semibold text-slate-900">{selectedRequest.hospitalName}</span> ·{' '}
                  <span className="font-mono-tabular font-bold text-red-600">
                    {selectedRequest.bloodGroup}
                  </span>{' '}
                  ({selectedRequest.bloodKind}) · {selectedRequest.unitsCommitted}/
                  {selectedRequest.unitsNeeded} units
                </p>
              </div>
              <span className="text-xs font-mono-tabular text-slate-500">
                Click any blood-type pin to inspect route
              </span>
            </div>

            <HospitalRoutingMap
              request={selectedRequest}
              allActiveRequests={mapVisibleRequests}
              onSelectRequest={(id) => setSelectedRequestId(id)}
              userLocation={{
                lat: location.lat,
                lng: location.lng,
                label: location.label,
              }}
              eligibleDonors={eligibleDonors}
              responses={responses}
              radiusKm={radiusKm}
              heightClass="h-[440px]"
            />
          </div>

          {/* Active SOS Requests Sorted by Distance from User */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
            <h3 className="text-sm font-bold text-slate-950">
              Active SOS Requests Nearest to Your Location
            </h3>
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
              {sortedActiveRequests.length === 0 ? (
                <p className="p-4 text-xs text-slate-500 text-center">
                  No active SOS requests match {bloodFilter}.
                </p>
              ) : (
                sortedActiveRequests.map(
                  ({ request: r, distanceFromUser, etaFromUser }) => {
                    const isSelected = r.id === selectedRequest.id;
                    return (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => setSelectedRequestId(r.id)}
                        className={`w-full text-left px-4 py-3 flex items-center justify-between gap-3 transition-colors ${
                          isSelected ? 'bg-red-50/70' : 'hover:bg-slate-50'
                        }`}
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-mono-tabular text-xs font-bold text-red-700 bg-red-50 border border-red-200 rounded px-1.5 py-0.5">
                              {r.bloodGroup}
                            </span>
                            <span className="text-sm font-semibold text-slate-900 truncate">
                              {r.hospitalName}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5 truncate">
                            {r.id} · {r.bloodKind} · {r.unitsCommitted}/{r.unitsNeeded}{' '}
                            units · {r.locality}
                          </p>
                        </div>
                        <div className="text-right shrink-0 font-mono-tabular text-xs">
                          <div className="font-semibold text-blue-700 flex items-center justify-end gap-1">
                            <Navigation className="w-3 h-3" />
                            {distanceFromUser} km
                          </div>
                          <div className="text-slate-500">~{etaFromUser} min</div>
                        </div>
                      </button>
                    );
                  }
                )
              )}
            </div>
          </div>
        </section>

        {/* Right: Lifecycle Tracking + SMS SOS Dispatch Simulator + Gemini Maps Grounding */}
        <section className="lg:col-span-5 space-y-6">
          {/* Interactive Receiver Lifecycle Tracking */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs font-medium text-slate-500">
                Focused Request:{' '}
                <span className="font-mono-tabular font-semibold text-slate-900">
                  {selectedRequest.id}
                </span>{' '}
                · {selectedRequest.hospitalName}
              </p>
            </div>
            <LifecycleTracking
              request={selectedRequest}
              isExpired={formatCountdown(selectedRequest.expiresAt, nowMs).isExpired}
              compact
            />
          </div>

          {/* SMS SOS Dispatch Simulator */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-950 flex items-center gap-2">
                <Radio className="w-4 h-4 text-red-600" />
                SMS SOS Dispatch Simulator
              </h2>
              <p className="mt-1 text-xs text-slate-600">
                Broadcasts instant simulated relay alerts for{' '}
                <span className="font-mono-tabular font-semibold">
                  {selectedRequest.id}
                </span>{' '}
                to compatible, unlocked donors within 25 km.
              </p>
            </div>

            <button
              type="button"
              onClick={() =>
                void dispatchSmsBroadcast(selectedRequest.id, Math.min(radiusKm, 25))
              }
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 transition-colors"
            >
              <Send className="w-4 h-4" />
              Dispatch SMS SOS to {eligibleDonors.length} Eligible Donor(s)
            </button>

            <div className="pt-2 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold text-slate-700">
                  Simulated Dispatch Log ({requestSmsLogs.length})
                </span>
                <span>Masked numbers only</span>
              </div>

              {requestSmsLogs.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-500 border border-dashed border-slate-200 rounded-lg">
                  No SMS alerts dispatched for {selectedRequest.id} yet.
                </div>
              ) : (
                <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 max-h-56 overflow-y-auto">
                  {requestSmsLogs.map((log) => (
                    <div key={log.id} className="p-3 space-y-1 text-xs">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-semibold text-slate-900">
                          {log.donorInitials} ({log.donorBloodGroup}) ·{' '}
                          <span className="font-mono-tabular font-normal text-slate-600">
                            {log.maskedPhone}
                          </span>
                        </span>
                        <span className="font-mono-tabular text-emerald-700 font-semibold shrink-0">
                          {log.deliveryStatus} · {log.distanceKm} km
                        </span>
                      </div>
                      <p className="text-slate-600 leading-relaxed">
                        {log.messagePreview}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Gemini Maps Grounding Panel */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-950">
                Nearby Blood Banks & Trauma Centers
              </h2>
              <p className="mt-1 text-xs text-slate-600">
                Grounded real-world hospital & blood bank lookup centered at your
                current coordinates ({location.lat.toFixed(3)},{' '}
                {location.lng.toFixed(3)}).
              </p>
            </div>

            <form onSubmit={handleMapsGroundingSearch} className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={groundingQuery}
                  onChange={(e) => setGroundingQuery(e.target.value)}
                  placeholder="Search blood banks or hospitals nearby..."
                  className="w-full pl-8 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                />
              </div>
              <button
                type="submit"
                disabled={groundingLoading}
                className="px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-60 whitespace-nowrap"
              >
                {groundingLoading ? (
                  <span className="inline-flex items-center gap-1.5">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    Searching
                  </span>
                ) : (
                  'Find Nearby'
                )}
              </button>
            </form>

            {groundingError && (
              <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800">
                {groundingError}
              </div>
            )}

            {groundingText && (
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700 whitespace-pre-line leading-relaxed max-h-48 overflow-y-auto">
                {groundingText}
              </div>
            )}

            {groundingPlaces.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-slate-700">
                  Verified Google Maps Place Links ({groundingPlaces.length})
                </p>
                <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 max-h-56 overflow-y-auto">
                  {groundingPlaces.map((place, idx) => (
                    <a
                      key={`${place.uri}-${idx}`}
                      href={place.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-start justify-between gap-2 p-3 hover:bg-slate-50 transition-colors"
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-blue-700 hover:underline truncate">
                          {place.title}
                        </p>
                        {place.snippets[0] && (
                          <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">
                            {place.snippets[0]}
                          </p>
                        )}
                      </div>
                      <ExternalLink className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
