import { useMemo, useState } from 'react';
import { Lock, RotateCcw, Search, ShieldCheck } from 'lucide-react';
import { useRedRelay } from '../context/RedRelayContext';
import { CITIES, HOSPITALS } from '../data/seedData';
import type { BloodGroup } from '../types/redrelay';
import {
  BLOOD_GROUPS,
  COMPATIBLE_DONORS_FOR_RECIPIENT,
  estimateDriveMinutes,
  getRecoveryStatus,
  haversineDistanceKm,
  isCompatibleDonor,
} from '../utils/compatibility';

export function DonorRegistryPage() {
  const { donors, nowMs, toggleDonorAvailability, resetDemoData } = useRedRelay();

  const [searchQuery, setSearchQuery] = useState('');
  const [cityFilter, setCityFilter] = useState<string>('All');
  const [recipientFilter, setRecipientFilter] = useState<BloodGroup | 'All'>('All');
  const [refHospitalId, setRefHospitalId] = useState<string>(HOSPITALS[0].id);
  const [radiusKm, setRadiusKm] = useState<number | 'All'>('All');

  const refHospital = useMemo(
    () => HOSPITALS.find((h) => h.id === refHospitalId) ?? HOSPITALS[0],
    [refHospitalId]
  );

  const filteredDonors = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return donors
      .map((donor) => {
        const distanceKm = haversineDistanceKm(
          refHospital.lat,
          refHospital.lng,
          donor.lat,
          donor.lng
        );
        return {
          donor,
          distanceKm,
          etaMinutes: estimateDriveMinutes(distanceKm),
          recovery: getRecoveryStatus(donor, nowMs),
        };
      })
      .filter(({ donor, distanceKm }) => {
        if (cityFilter !== 'All' && donor.city !== cityFilter) return false;
        if (
          recipientFilter !== 'All' &&
          !isCompatibleDonor(donor.bloodGroup, recipientFilter)
        ) {
          return false;
        }
        if (radiusKm !== 'All' && distanceKm > radiusKm) return false;
        if (q) {
          const haystack = `${donor.initials} ${donor.bloodGroup} ${donor.locality} ${donor.city}`.toLowerCase();
          if (!haystack.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => a.distanceKm - b.distanceKm);
  }, [donors, refHospital, cityFilter, recipientFilter, radiusKm, searchQuery, nowMs]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="max-w-2xl">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
            Voluntary Donor Registry & Compatibility Matrix
          </h1>
          <p className="mt-2 text-sm sm:text-base text-slate-600 leading-relaxed">
            Privacy-masked registry of {donors.length} voluntary donors across 8
            ABO/Rh blood groups. Raw phone numbers are never exposed publicly.
          </p>
        </div>

        <button
          type="button"
          onClick={resetDemoData}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 self-start"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset Demo Dataset
        </button>
      </section>

      {/* Geographic Locality & Clinical Compatibility Filter Toolbar */}
      <section className="bg-white border border-slate-200 rounded-xl p-4 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search locality, initials, group..."
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
            />
          </div>

          <select
            aria-label="Filter registry by city"
            value={cityFilter}
            onChange={(e) => setCityFilter(e.target.value)}
            className="px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white text-slate-800"
          >
            <option value="All">All Cities</option>
            {CITIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter compatible donors for patient blood group"
            value={recipientFilter}
            onChange={(e) =>
              setRecipientFilter(e.target.value as BloodGroup | 'All')
            }
            className="px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white text-slate-800"
          >
            <option value="All">Compatible With: Any Patient</option>
            {BLOOD_GROUPS.map((bg) => (
              <option key={bg} value={bg}>
                Can Donate to {bg} Patient
              </option>
            ))}
          </select>

          <select
            aria-label="Reference hospital for distance calculation"
            value={refHospitalId}
            onChange={(e) => setRefHospitalId(e.target.value)}
            className="px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white text-slate-800"
          >
            {HOSPITALS.map((h) => (
              <option key={h.id} value={h.id}>
                Distance from: {h.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-slate-500">
              Proximity Radius from {refHospital.locality}:
            </span>
            <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              {([5, 10, 25, 'All'] as const).map((rad) => (
                <button
                  key={rad}
                  type="button"
                  onClick={() => setRadiusKm(rad)}
                  className={`px-2.5 py-1 text-xs font-mono-tabular font-medium rounded-md transition-colors ${
                    radiusKm === rad
                      ? 'bg-white text-slate-950 shadow-xs'
                      : 'text-slate-600 hover:text-slate-950'
                  }`}
                >
                  {rad === 'All' ? 'All Distances' : `${rad} km`}
                </button>
              ))}
            </div>
          </div>

          <p className="text-xs text-slate-500 font-mono-tabular">
            Showing {filteredDonors.length} of {donors.length} registered donors
          </p>
        </div>
      </section>

      {/* Donor Registry Data Table */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <th className="py-3 px-4">Donor</th>
                <th className="py-3 px-4">Blood Group</th>
                <th className="py-3 px-4">City / Locality</th>
                <th className="py-3 px-4">Masked Contact</th>
                <th className="py-3 px-4 text-right">Distance / ETA</th>
                <th className="py-3 px-4">Clinical Status</th>
                <th className="py-3 px-4 text-right">Availability</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {filteredDonors.length === 0 ? (
                <tr>
                  <td
                    colSpan={7}
                    className="py-10 px-4 text-center text-sm text-slate-500"
                  >
                    No registered donors match the selected radius or compatibility
                    filters.
                  </td>
                </tr>
              ) : (
                filteredDonors.map(
                  ({ donor, distanceKm, etaMinutes, recovery }) => (
                    <tr
                      key={donor.id}
                      className="hover:bg-slate-50/70 transition-colors"
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-900">
                            {donor.initials}
                          </span>
                          {donor.verified && (
                            <ShieldCheck
                              className="w-3.5 h-3.5 text-emerald-600"
                              aria-label="Verified donor"
                            />
                          )}
                        </div>
                        <p className="text-xs text-slate-500 font-mono-tabular">
                          {donor.totalUnitsGiven} unit(s) given ·{' '}
                          {donor.totalDonations} donation(s)
                        </p>
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-block font-mono-tabular font-bold text-red-700 bg-red-50 border border-red-200 rounded px-2 py-0.5 text-xs">
                          {donor.bloodGroup}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-700">
                        <span className="font-medium text-slate-900">
                          {donor.locality}
                        </span>
                        <span className="text-slate-400"> · </span>
                        <span className="text-xs text-slate-500">
                          {donor.city}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono-tabular text-xs text-slate-600">
                        {donor.maskedPhone}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-tabular text-xs text-slate-700">
                        {distanceKm} km · ~{etaMinutes} min
                      </td>
                      <td className="py-3 px-4 text-xs">
                        {recovery.isLocked ? (
                          <span className="inline-flex items-center gap-1 font-medium text-amber-800">
                            <Lock className="w-3.5 h-3.5 text-amber-600" />
                            90d Recovery ({recovery.daysRemaining}d left)
                          </span>
                        ) : donor.isAvailable ? (
                          <span className="font-semibold text-emerald-700">
                            Ready to Donate
                          </span>
                        ) : (
                          <span className="text-slate-500">Paused by Donor</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          disabled={recovery.isLocked}
                          onClick={() => toggleDonorAvailability(donor.id)}
                          className={`px-2.5 py-1 text-xs font-medium rounded-md border transition-colors ${
                            recovery.isLocked
                              ? 'border-slate-200 text-slate-400 bg-slate-50 cursor-not-allowed'
                              : donor.isAvailable
                              ? 'border-slate-200 text-slate-700 hover:bg-slate-100'
                              : 'border-emerald-200 text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
                          }`}
                        >
                          {recovery.isLocked
                            ? 'Locked'
                            : donor.isAvailable
                            ? 'Pause'
                            : 'Activate'}
                        </button>
                      </td>
                    </tr>
                  )
                )
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Clinical ABO/Rh Compatibility Matrix Reference */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div>
          <h2 className="text-base font-bold text-slate-950">
            Clinical ABO / Rh Red-Cell Compatibility Matrix
          </h2>
          <p className="mt-1 text-xs text-slate-600">
            Hardcoded biological matching rules enforced by the RedRelay engine:
            rows show recipient blood groups; columns show eligible donor groups.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-center border-collapse text-xs font-mono-tabular">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-700">
                <th className="py-2.5 px-3 text-left font-sans font-semibold">
                  Recipient \ Donor
                </th>
                {BLOOD_GROUPS.map((donorGroup) => (
                  <th key={donorGroup} className="py-2.5 px-2 font-bold">
                    {donorGroup}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {BLOOD_GROUPS.map((recipientGroup) => {
                const allowed = COMPATIBLE_DONORS_FOR_RECIPIENT[recipientGroup];
                return (
                  <tr key={recipientGroup}>
                    <td className="py-2.5 px-3 text-left font-bold text-slate-900 bg-slate-50/50">
                      {recipientGroup} Patient
                    </td>
                    {BLOOD_GROUPS.map((donorGroup) => {
                      const ok = allowed.includes(donorGroup);
                      return (
                        <td
                          key={donorGroup}
                          className={`py-2.5 px-2 ${
                            ok
                              ? 'bg-emerald-50/70 text-emerald-800 font-semibold'
                              : 'text-slate-300'
                          }`}
                        >
                          {ok ? 'Match' : '—'}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
