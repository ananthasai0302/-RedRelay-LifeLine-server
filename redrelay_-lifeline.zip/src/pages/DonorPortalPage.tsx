import React, { useMemo, useState } from 'react';
import {
  Award,
  CheckCircle2,
  Clock,
  Lock,
  LogIn,
  Navigation,
  Shield,
  UserPlus,
} from 'lucide-react';
import { useRedRelay } from '../context/RedRelayContext';
import { CITIES, LOCALITIES } from '../data/seedData';
import type { BloodGroup } from '../types/redrelay';
import {
  BLOOD_GROUPS,
  COMPATIBLE_RECIPIENTS_FOR_DONOR,
  estimateDriveMinutes,
  formatCountdown,
  getRecoveryStatus,
  haversineDistanceKm,
  isCompatibleDonor,
  RECOVERY_LOCK_DAYS,
} from '../utils/compatibility';
import { CertificateModal } from '../components/CertificateModal';
import type { CertificateDetails } from '../utils/certificateGenerator';

export function DonorPortalPage() {
  const {
    user,
    privateProfile,
    signInWithGoogle,
    donors,
    requests,
    responses,
    activeDonorId,
    setActiveDonorId,
    commitToRequest,
    registerDonor,
    toggleDonorAvailability,
    nowMs,
  } = useRedRelay();

  const [portalTab, setPortalTab] = useState<'respond' | 'register'>('respond');
  const [certDetails, setCertDetails] = useState<CertificateDetails | null>(null);
  const [unitsByRequest, setUnitsByRequest] = useState<Record<string, number>>({});

  // Registration form state (Donor Name, Blood Group, Phone Number, Units Given)
  const [fullName, setFullName] = useState('');
  const [regBloodGroup, setRegBloodGroup] = useState<BloodGroup>('O+');
  const [regCity, setRegCity] = useState<string>('Hyderabad, Telangana');
  const [regLocality, setRegLocality] = useState<string>('Banjara Hills');
  const [regPhone, setRegPhone] = useState('');
  const [initialUnitsGiven, setInitialUnitsGiven] = useState<number>(1);
  const [regError, setRegError] = useState('');
  const [regSubmitting, setRegSubmitting] = useState(false);

  const cityLocalities = useMemo(
    () => LOCALITIES.filter((l) => l.city === regCity),
    [regCity]
  );

  const activeDonor = useMemo(
    () => donors.find((d) => d.id === activeDonorId) ?? donors[0],
    [donors, activeDonorId]
  );

  const isOwnedByCurrentUser =
    Boolean(user) && activeDonor.ownerUid === user?.uid && Boolean(privateProfile);

  const recovery = useMemo(
    () => getRecoveryStatus(activeDonor, nowMs),
    [activeDonor, nowMs]
  );

  const matchingRequests = useMemo(() => {
    return requests
      .filter((req) => {
        const countdown = formatCountdown(req.expiresAt, nowMs);
        if (req.status === 'Closed' || countdown.isExpired) return false;
        return isCompatibleDonor(activeDonor.bloodGroup, req.bloodGroup);
      })
      .map((req) => {
        const distanceKm = haversineDistanceKm(
          req.lat,
          req.lng,
          activeDonor.lat,
          activeDonor.lng
        );
        const etaMinutes = estimateDriveMinutes(distanceKm);
        const alreadyCommitted = responses.some(
          (r) => r.requestId === req.id && r.donorId === activeDonor.id
        );
        return {
          request: req,
          distanceKm,
          etaMinutes,
          alreadyCommitted,
        };
      })
      .sort((a, b) => a.distanceKm - b.distanceKm);
  }, [requests, activeDonor, responses, nowMs]);

  const completedDonations = useMemo(() => {
    return responses
      .filter(
        (r) => r.donorId === activeDonor.id && r.status === 'Donated'
      )
      .map((r) => {
        const req = requests.find((rq) => rq.id === r.requestId);
        return {
          response: r,
          hospitalName: req?.hospitalName ?? 'Verified Partner Hospital',
          city: req?.city ?? activeDonor.city,
          donatedAt: req?.closedAt ?? r.createdAt,
        };
      });
  }, [responses, requests, activeDonor]);

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setRegError(
        'Please sign in with Google before registering a donor profile in Firestore.'
      );
      return;
    }
    if (!fullName.trim()) {
      setRegError('Please enter your full name (only initials appear publicly).');
      return;
    }
    if (regPhone.replace(/\D/g, '').length < 7) {
      setRegError('Please enter a valid phone number for private relay routing.');
      return;
    }
    setRegError('');
    setRegSubmitting(true);
    try {
      const created = await registerDonor({
        fullName,
        bloodGroup: regBloodGroup,
        city: regCity,
        locality: regLocality,
        phone: regPhone,
        initialUnitsGiven,
      });
      if (created) {
        setFullName('');
        setRegPhone('');
        setInitialUnitsGiven(1);
        setPortalTab('respond');
      }
    } finally {
      setRegSubmitting(false);
    }
  };

  const openCertificateForDonation = (
    requestId: string,
    hospitalName: string,
    city: string,
    donatedAt: string
  ) => {
    setCertDetails({
      donorName: isOwnedByCurrentUser
        ? privateProfile!.fullName
        : activeDonor.fullName,
      donorInitials: activeDonor.initials,
      bloodGroup: activeDonor.bloodGroup,
      hospitalName,
      city,
      requestId,
      donatedAt,
      certificateId: `RLY-${requestId.replace('SOS-', '')}-${activeDonor.bloodGroup}`,
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="max-w-2xl">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
            Voluntary Donor Portal
          </h1>
          <p className="mt-2 text-sm sm:text-base text-slate-600 leading-relaxed">
            Register your donor details (name, blood group, private phone number,
            and units given), pledge 1–2 blood units to compatible SOS requests,
            and manage your 90-day clinical recovery lock.
          </p>
        </div>

        <div className="inline-flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg self-start">
          <button
            type="button"
            onClick={() => setPortalTab('respond')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              portalTab === 'respond'
                ? 'bg-white text-slate-950 shadow-xs'
                : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            Donor Response View
          </button>
          <button
            type="button"
            onClick={() => setPortalTab('register')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              portalTab === 'register'
                ? 'bg-white text-slate-950 shadow-xs'
                : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            Register New Donor
          </button>
        </div>
      </section>

      {!user && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs sm:text-sm text-amber-900">
            Sign in with Google to register your private donor profile and pledge
            blood units to live Firestore requests.
          </p>
          <button
            type="button"
            onClick={() => void signInWithGoogle()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800"
          >
            <LogIn className="w-3.5 h-3.5" />
            Sign In with Google
          </button>
        </div>
      )}

      {portalTab === 'register' ? (
        <section className="max-w-2xl bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div>
            <h2 className="text-lg font-bold text-slate-950">
              Register as a Voluntary Blood Donor
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-slate-600">
              Your name and phone number are stored in your private owner-only
              Firestore profile and masked in public feeds.
            </p>
          </div>

          {regError && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800">
              {regError}
            </div>
          )}

          <form onSubmit={handleRegisterSubmit} className="space-y-4">
            <div>
              <label
                htmlFor="donor-fullname"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Donor Name (Stored privately; initials shown publicly)
              </label>
              <input
                id="donor-fullname"
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g., Aditi Kulkarni"
                className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
              />
            </div>

            <div>
              <span className="block text-xs font-semibold text-slate-700 mb-2">
                Donor Blood Group
              </span>
              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                {BLOOD_GROUPS.map((bg) => (
                  <button
                    key={bg}
                    type="button"
                    onClick={() => setRegBloodGroup(bg)}
                    className={`py-2 rounded-lg border text-sm font-mono-tabular font-bold transition-colors ${
                      regBloodGroup === bg
                        ? 'bg-red-600 border-red-600 text-white'
                        : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    {bg}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="reg-phone"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Donor Phone Number (Private Relay)
                </label>
                <input
                  id="reg-phone"
                  type="tel"
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  placeholder="+91 98450 12345"
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                />
              </div>

              <div>
                <label
                  htmlFor="reg-units-given"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  How Many Units of Blood Given (Lifetime / Prior)
                </label>
                <input
                  id="reg-units-given"
                  type="number"
                  min={0}
                  max={100}
                  value={initialUnitsGiven}
                  onChange={(e) =>
                    setInitialUnitsGiven(Math.max(0, Number(e.target.value)))
                  }
                  className="w-full px-3.5 py-2.5 text-sm font-mono-tabular border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="reg-city"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  City
                </label>
                <select
                  id="reg-city"
                  value={regCity}
                  onChange={(e) => {
                    const nextCity = e.target.value;
                    setRegCity(nextCity);
                    const firstLoc = LOCALITIES.find((l) => l.city === nextCity);
                    if (firstLoc) setRegLocality(firstLoc.locality);
                  }}
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-lg bg-white"
                >
                  {CITIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="reg-locality"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Locality / Neighborhood
                </label>
                <select
                  id="reg-locality"
                  value={regLocality}
                  onChange={(e) => setRegLocality(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-lg bg-white"
                >
                  {cityLocalities.map((l) => (
                    <option key={l.locality} value={l.locality}>
                      {l.locality}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between gap-4 border-t border-slate-100">
              <span className="inline-flex items-center gap-1.5 text-xs text-slate-500">
                <Shield className="w-4 h-4 text-emerald-600" />
                Zero public phone exposure
              </span>
              <button
                type="submit"
                disabled={regSubmitting}
                className="px-5 py-2.5 text-sm font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 disabled:opacity-60 transition-colors"
              >
                {regSubmitting ? 'Saving...' : 'Complete Donor Registration'}
              </button>
            </div>
          </form>
        </section>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <aside className="lg:col-span-4 space-y-5">
            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div>
                <label
                  htmlFor="active-donor-select"
                  className="block text-xs font-semibold text-slate-500 mb-1.5"
                >
                  Active Donor Profile (Switcher)
                </label>
                <select
                  id="active-donor-select"
                  value={activeDonor.id}
                  onChange={(e) => setActiveDonorId(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-medium bg-slate-50 border border-slate-200 rounded-lg text-slate-900"
                >
                  {donors.map((d) => {
                    const rec = getRecoveryStatus(d, nowMs);
                    return (
                      <option key={d.id} value={d.id}>
                        {d.initials} ({d.bloodGroup}) — {d.locality}, {d.city}
                        {rec.isLocked ? ` [Locked ${rec.daysRemaining}d]` : ''}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                <div>
                  <p className="text-base font-bold text-slate-950">
                    {isOwnedByCurrentUser
                      ? privateProfile!.fullName
                      : activeDonor.fullName}{' '}
                    <span className="text-xs font-normal text-slate-500">
                      (Public: {activeDonor.initials})
                    </span>
                  </p>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {activeDonor.locality}, {activeDonor.city} ·{' '}
                    <span className="font-mono-tabular">
                      {isOwnedByCurrentUser
                        ? privateProfile!.phone
                        : activeDonor.maskedPhone}
                    </span>
                  </p>
                </div>
                <div className="w-12 h-12 rounded-xl bg-red-50 border border-red-200 flex items-center justify-center font-mono-tabular font-bold text-red-700 text-base shrink-0">
                  {activeDonor.bloodGroup}
                </div>
              </div>

              <div className="text-xs text-slate-600 space-y-1.5 pt-2 border-t border-slate-100">
                <div className="flex justify-between">
                  <span>Can Donate To</span>
                  <span className="font-mono-tabular font-semibold text-slate-900">
                    {COMPATIBLE_RECIPIENTS_FOR_DONOR[activeDonor.bloodGroup].join(
                      ', '
                    )}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Total Units of Blood Given</span>
                  <span className="font-mono-tabular font-semibold text-slate-900">
                    {activeDonor.totalUnitsGiven} unit(s) ({activeDonor.totalDonations}{' '}
                    visit{activeDonor.totalDonations === 1 ? '' : 's'})
                  </span>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-800">
                    90-Day Recovery & Availability
                  </span>
                  <span
                    className={`text-xs font-semibold ${
                      recovery.isLocked
                        ? 'text-amber-700'
                        : activeDonor.isAvailable
                        ? 'text-emerald-700'
                        : 'text-slate-500'
                    }`}
                  >
                    {recovery.isLocked
                      ? `Locked (${recovery.daysRemaining}d left)`
                      : activeDonor.isAvailable
                      ? 'Available'
                      : 'Paused'}
                  </span>
                </div>

                {recovery.isLocked ? (
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 space-y-2">
                    <div className="flex items-start gap-2 text-xs text-amber-900">
                      <Lock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                      <span>
                        Clinical safety lock active for {RECOVERY_LOCK_DAYS} days
                        post-donation. Eligible again in{' '}
                        <strong className="font-mono-tabular">
                          {recovery.daysRemaining} day(s)
                        </strong>
                        .
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-amber-200/70 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-600"
                        style={{
                          width: `${Math.round(
                            (recovery.daysElapsed / RECOVERY_LOCK_DAYS) * 100
                          )}%`,
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => void toggleDonorAvailability(activeDonor.id)}
                    className={`w-full py-2 px-3 rounded-lg border text-xs font-semibold transition-colors ${
                      activeDonor.isAvailable
                        ? 'border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                        : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {activeDonor.isAvailable
                      ? 'Status: Available (Click to Pause)'
                      : 'Status: Paused (Click to Go Available)'}
                  </button>
                )}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold text-slate-900">
                  Appreciation Certificates
                </h2>
                <Award className="w-4 h-4 text-red-600" />
              </div>

              {completedDonations.length > 0 ? (
                <div className="space-y-2">
                  {completedDonations.map((item) => (
                    <div
                      key={item.response.id}
                      className="p-3 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-slate-900 truncate">
                          {item.hospitalName}
                        </p>
                        <p className="text-[11px] text-slate-500 font-mono-tabular">
                          {item.response.requestId} · {item.response.unitsCommitted} unit(s)
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          openCertificateForDonation(
                            item.response.requestId,
                            item.hospitalName,
                            item.city,
                            item.donatedAt
                          )
                        }
                        className="px-2.5 py-1.5 text-xs font-semibold text-white bg-red-600 rounded-md hover:bg-red-700 shrink-0"
                      >
                        Certificate
                      </button>
                    </div>
                  ))}
                </div>
              ) : activeDonor.totalUnitsGiven > 0 ? (
                <div className="p-3 rounded-lg border border-slate-200 bg-slate-50 space-y-2.5">
                  <p className="text-xs text-slate-600">
                    Donor {activeDonor.initials} has{' '}
                    <span className="font-mono-tabular font-semibold">
                      {activeDonor.totalUnitsGiven}
                    </span>{' '}
                    verified blood unit(s) given on record.
                  </p>
                  <button
                    type="button"
                    onClick={() =>
                      openCertificateForDonation(
                        'SOS-PAST-VERIFIED',
                        'RedRelay Partner Blood Network',
                        activeDonor.city,
                        activeDonor.lastDonationDate ?? new Date().toISOString()
                      )
                    }
                    className="w-full py-2 text-xs font-semibold text-slate-900 bg-white border border-slate-200 rounded-lg hover:bg-slate-100"
                  >
                    Preview & Download Recognition Badge
                  </button>
                </div>
              ) : (
                <p className="text-xs text-slate-500">
                  Certificates unlock automatically once a committed SOS request is
                  marked Blood Received.
                </p>
              )}
            </div>
          </aside>

          <div className="lg:col-span-8 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-950">
                Compatible Emergency Requests for {activeDonor.bloodGroup} (
                {matchingRequests.length})
              </h2>
              <span className="text-xs text-slate-500">
                Sorted by distance from {activeDonor.locality}
              </span>
            </div>

            {matchingRequests.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-xl p-8 text-center">
                <p className="text-sm font-semibold text-slate-900">
                  No active SOS requests require {activeDonor.bloodGroup}{' '}
                  compatibility right now.
                </p>
                <p className="mt-1 text-xs text-slate-500">
                  Switch donor profile on the left or check the full Broadcast Feed.
                </p>
              </div>
            ) : (
              matchingRequests.map(
                ({ request: req, distanceKm, etaMinutes, alreadyCommitted }) => {
                  const countdown = formatCountdown(req.expiresAt, nowMs);
                  const remainingNeeded = Math.max(
                    1,
                    req.unitsNeeded - req.unitsCommitted
                  );
                  const chosenUnits = unitsByRequest[req.id] ?? 1;
                  const canCommit =
                    !alreadyCommitted &&
                    !recovery.isLocked &&
                    activeDonor.isAvailable &&
                    req.unitsCommitted < req.unitsNeeded;

                  return (
                    <article
                      key={req.id}
                      className="bg-white border border-slate-200 rounded-xl p-5 space-y-4"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                        <div className="space-y-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-mono-tabular text-xs font-bold text-red-700 bg-red-50 border border-red-200 rounded px-2 py-0.5">
                              {req.bloodGroup}
                            </span>
                            <span className="text-xs font-medium text-slate-600">
                              {req.bloodKind}
                            </span>
                            <h3 className="text-base font-bold text-slate-950 truncate">
                              {req.hospitalName}
                            </h3>
                          </div>
                          <p className="text-xs text-slate-600">
                            <span className="font-mono-tabular font-medium text-slate-800">
                              {req.id}
                            </span>{' '}
                            · Patient: {req.patientName} · {req.locality}, {req.city}
                          </p>
                          <p className="text-xs text-slate-500">
                            {req.doctorContact}
                          </p>
                        </div>

                        <div className="sm:text-right shrink-0 space-y-1">
                          <div className="inline-flex items-center gap-1.5 text-xs font-mono-tabular font-semibold text-slate-900">
                            <Navigation className="w-3.5 h-3.5 text-slate-500" />
                            {distanceKm} km · ~{etaMinutes} min drive
                          </div>
                          <div className="flex sm:justify-end items-center gap-1.5 text-xs font-mono-tabular text-red-600">
                            <Clock className="w-3.5 h-3.5" />
                            {countdown.label}
                          </div>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                        <div className="text-xs text-slate-600">
                          Progress:{' '}
                          <span className="font-mono-tabular font-bold text-slate-950">
                            {req.unitsCommitted} / {req.unitsNeeded} Units Committed
                          </span>{' '}
                          · Stage: <span className="font-medium">{req.status}</span>
                        </div>

                        {alreadyCommitted ? (
                          <span className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            Unit(s) Committed via Relay
                          </span>
                        ) : (
                          <div className="flex items-center gap-2">
                            <select
                              aria-label="Select blood units to give"
                              value={Math.min(chosenUnits, remainingNeeded)}
                              onChange={(e) =>
                                setUnitsByRequest((prev) => ({
                                  ...prev,
                                  [req.id]: Number(e.target.value),
                                }))
                              }
                              className="px-2.5 py-2 text-xs font-mono-tabular bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
                            >
                              {Array.from(
                                { length: Math.min(remainingNeeded, 2) },
                                (_, i) => i + 1
                              ).map((u) => (
                                <option key={u} value={u}>
                                  {u} {u === 1 ? 'Unit' : 'Units'}
                                </option>
                              ))}
                            </select>

                            <button
                              type="button"
                              disabled={!canCommit}
                              onClick={() =>
                                void commitToRequest(
                                  req.id,
                                  activeDonor.id,
                                  Math.min(chosenUnits, remainingNeeded)
                                )
                              }
                              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                                canCommit
                                  ? 'bg-red-600 text-white hover:bg-red-700'
                                  : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                              }`}
                            >
                              {recovery.isLocked
                                ? `Locked (${recovery.daysRemaining}d recovery)`
                                : !activeDonor.isAvailable
                                ? 'Enable Availability to Respond'
                                : req.unitsCommitted >= req.unitsNeeded
                                ? 'Units Already Fulfilled'
                                : `I Can Donate (${Math.min(
                                    chosenUnits,
                                    remainingNeeded
                                  )} Unit${
                                    Math.min(chosenUnits, remainingNeeded) > 1
                                      ? 's'
                                      : ''
                                  })`}
                            </button>
                          </div>
                        )}
                      </div>
                    </article>
                  );
                }
              )
            )}
          </div>
        </div>
      )}

      <CertificateModal
        details={certDetails}
        onClose={() => setCertDetails(null)}
      />
    </div>
  );
}
