import React, { useEffect, useRef, useState } from 'react';
import { Loader2, MessageSquare, RotateCcw, Send, X } from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  model?: string;
}

type AssistantRoleMode = 'coordinator' | 'donor_advisor' | 'quick_triage';

const ROLE_OPTIONS: Array<{
  id: AssistantRoleMode;
  label: string;
  hint: string;
}> = [
  {
    id: 'coordinator',
    label: 'SOS Coordinator',
    hint: 'gemini-4-hydrogen · Compatibility & hospital dispatch',
  },
  {
    id: 'donor_advisor',
    label: 'Donor Advisor',
    hint: 'gemini-4-hydrogen · 90-day recovery & donor prep',
  },
  {
    id: 'quick_triage',
    label: 'Quick Triage',
    hint: 'gemini-3.1-flash-lite · Fast checklists',
  },
];

const STARTER_PROMPTS = [
  'Which donor blood groups can donate PRBC to a B+ patient?',
  'How does the 90-day donor recovery lock work?',
  'What details should I prepare before visiting Apollo Jubilee Hills?',
];

export function ClinicalAssistantDrawer() {
  const [open, setOpen] = useState(false);
  const [roleMode, setRoleMode] = useState<AssistantRoleMode>('coordinator');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const scrollEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (open) {
      scrollEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, open, loading]);

  const sendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || loading) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: trimmed,
    };

    const nextHistory = messages.map((m) => ({
      role: m.role,
      text: m.text,
    }));

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setErrorMsg('');
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          history: nextHistory,
          roleMode,
        }),
      });

      const data = (await res.json()) as {
        reply?: string;
        model?: string;
        error?: string;
      };

      if (!res.ok) {
        throw new Error(data.error || `Server returned ${res.status}`);
      }

      const replyText =
        data.reply?.trim() || 'No response text was returned by the model.';
      setMessages((prev) => [
        ...prev,
        {
          id: `model-${Date.now()}`,
          role: 'model',
          text: replyText,
          model: data.model,
        },
      ]);
    } catch (err) {
      setErrorMsg(
        err instanceof Error
          ? err.message
          : 'Unable to reach RedRelay Gemini Assistant.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void sendMessage(input);
  };

  const currentRole =
    ROLE_OPTIONS.find((r) => r.id === roleMode) ?? ROLE_OPTIONS[0];

  return (
    <div className="fixed bottom-5 right-5 z-40">
      {!open ? (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-2 h-11 px-4 rounded-xl bg-slate-950 text-white text-xs sm:text-sm font-semibold shadow-lg hover:bg-red-600 transition-colors whitespace-nowrap"
        >
          <MessageSquare className="w-4 h-4 shrink-0" />
          Clinical Assistant
        </button>
      ) : (
        <aside
          aria-label="RedRelay Clinical Assistant"
          className="w-[390px] max-w-[calc(100vw-2rem)] h-[520px] max-h-[calc(100vh-3rem)] bg-white border border-slate-200 rounded-xl shadow-2xl flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between gap-2 shrink-0">
            <div className="min-w-0">
              <h2 className="text-sm font-bold text-slate-950 truncate">
                RedRelay Clinical Assistant
              </h2>
              <p className="text-[11px] text-slate-500 truncate">
                {currentRole.hint}
              </p>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              {messages.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    setMessages([]);
                    setErrorMsg('');
                  }}
                  title="Reset conversation"
                  aria-label="Reset conversation"
                  className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-200/70 transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={() => setOpen(false)}
                title="Close assistant"
                aria-label="Close assistant"
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-200/70 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Role Switcher */}
          <div className="px-3 py-2 border-b border-slate-100 bg-white flex items-center gap-1 shrink-0">
            {ROLE_OPTIONS.map((role) => (
              <button
                key={role.id}
                type="button"
                onClick={() => setRoleMode(role.id)}
                className={`flex-1 px-2 py-1.5 text-[11px] font-semibold rounded-md transition-colors whitespace-nowrap ${
                  roleMode === role.id
                    ? 'bg-red-50 text-red-700 border border-red-200'
                    : 'text-slate-600 hover:bg-slate-50 border border-transparent'
                }`}
              >
                {role.label}
              </button>
            ))}
          </div>

          {/* Scrollable Message Thread */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-white">
            {messages.length === 0 ? (
              <div className="space-y-3 py-2">
                <p className="text-xs text-slate-600 leading-relaxed">
                  Ask about ABO/Rh compatibility, blood components (PRBC,
                  Platelets, FFP), the 90-day recovery policy, or Hyderabad
                  hospital cross-match prep.
                </p>
                <div className="space-y-1.5">
                  {STARTER_PROMPTS.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      onClick={() => void sendMessage(prompt)}
                      className="w-full text-left px-3 py-2 text-xs text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${
                    msg.role === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-[85%] rounded-xl px-3.5 py-2.5 text-xs leading-relaxed whitespace-pre-line ${
                      msg.role === 'user'
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-800 border border-slate-200'
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))
            )}

            {loading && (
              <div className="flex justify-start">
                <div className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs text-slate-600">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-red-600" />
                  Generating response...
                </div>
              </div>
            )}

            {errorMsg && (
              <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800">
                {errorMsg}
              </div>
            )}
            <div ref={scrollEndRef} />
          </div>

          {/* Input Bar */}
          <form
            onSubmit={handleSubmit}
            className="p-3 border-t border-slate-200 bg-slate-50 flex items-center gap-2 shrink-0"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about compatibility, recovery, or SOS prep..."
              className="flex-1 px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              aria-label="Send message"
              className="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-red-600 text-white hover:bg-red-700 disabled:opacity-50 transition-colors shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </aside>
      )}
    </div>
  );
}
