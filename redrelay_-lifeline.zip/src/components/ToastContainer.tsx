import { X, CheckCircle2, AlertTriangle, Info } from 'lucide-react';
import { useRedRelay } from '../context/RedRelayContext';

export function ToastContainer() {
  const { toasts, dismissToast } = useRedRelay();

  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-4 sm:px-0"
    >
      {toasts.map((toast) => {
        const icon =
          toast.tone === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          ) : toast.tone === 'alert' ? (
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
          ) : (
            <Info className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
          );

        const borderClass =
          toast.tone === 'alert'
            ? 'border-red-200'
            : toast.tone === 'success'
            ? 'border-emerald-200'
            : 'border-slate-200';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto bg-white border ${borderClass} rounded-xl shadow-lg p-3.5 flex items-start gap-3 transition-all`}
          >
            {icon}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-slate-900">{toast.title}</p>
              {toast.detail && (
                <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                  {toast.detail}
                </p>
              )}
            </div>
            <button
              type="button"
              onClick={() => dismissToast(toast.id)}
              aria-label="Dismiss notification"
              className="text-slate-400 hover:text-slate-700 p-1 rounded"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
