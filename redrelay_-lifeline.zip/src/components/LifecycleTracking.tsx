import { useState } from 'react';
import { Check, Clock, Loader2, Lock, Radio, Truck, UserCheck } from 'lucide-react';
import type { BloodRequest, RequestStatus } from '../types/redrelay';
import { useRedRelay } from '../context/RedRelayContext';

interface StageConfig {
  key: RequestStatus;
  receiverLabel: string;
  clinicalLabel: string;
  description: string;
}

const LIFECYCLE_STAGES: StageConfig[] = [
  {
    key: 'Open / Broadcasted',
    receiverLabel: 'Pending',
    clinicalLabel: 'Open / Broadcasted',
    description: 'Awaiting donor match',
  },
  {
    key: 'Donors Responded',
    receiverLabel: 'In Progress',
    clinicalLabel: 'Donors Responded',
    description: 'Donor pledge active',
  },
  {
    key: 'Fulfilled / In Transit',
    receiverLabel: 'Fulfilled',
    clinicalLabel: 'In Transit',
    description: 'Units ready or en route',
  },
  {
    key: 'Closed',
    receiverLabel: 'Closed',
    clinicalLabel: 'Blood Received',
    description: 'Verified & 90d donor lock',
  },
];

function getStageIndex(status: RequestStatus): number {
  const idx = LIFECYCLE_STAGES.findIndex((s) => s.key === status);
  return idx >= 0 ? idx : 0;
}

export interface LifecycleTrackingProps {
  request: BloodRequest;
  isExpired?: boolean;
  compact?: boolean;
}

export function LifecycleTracking({
  request,
  isExpired = false,
  compact = false,
}: LifecycleTrackingProps) {
  const { user, signInWithGoogle, advanceRequestStatus, markBloodReceived } =
    useRedRelay();
  const [updatingStage, setUpdatingStage] = useState<RequestStatus | null>(null);

  const effectiveStatus: RequestStatus =
    isExpired && request.status !== 'Closed' ? 'Closed' : request.status;
  const currentIdx = getStageIndex(effectiveStatus);
  const currentStage = LIFECYCLE_STAGES[currentIdx];
  const isLockedClosed = effectiveStatus === 'Closed';

  const handleStageSelect = async (stage: StageConfig) => {
    if (isLockedClosed || updatingStage) return;
    if (stage.key === effectiveStatus) return;

    setUpdatingStage(stage.key);
    try {
      if (stage.key === 'Closed') {
        await markBloodReceived(request.id);
      } else {
        await advanceRequestStatus(request.id, stage.key);
      }
    } finally {
      setUpdatingStage(null);
    }
  };

  return (
    <section
      aria-label={`Lifecycle tracking for ${request.id}`}
      className="w-full space-y-2.5"
    >
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex flex-wrap items-center gap-2 text-slate-700">
          <span className="font-semibold text-slate-950">
            Lifecycle Tracking
          </span>
          <span className="text-slate-300" aria-hidden="true">
            ·
          </span>
          <span>
            Status:{' '}
            <strong className="font-semibold text-slate-950">
              {currentStage.receiverLabel}
            </strong>{' '}
            <span className="text-slate-500">
              ({currentStage.clinicalLabel})
            </span>
          </span>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500">
          {isLockedClosed ? (
            <span className="inline-flex items-center gap-1 text-slate-600 font-medium">
              <Lock className="w-3.5 h-3.5 text-slate-500" />
              Closed & locked
            </span>
          ) : !user ? (
            <button
              type="button"
              onClick={() => void signInWithGoogle()}
              className="font-medium text-red-600 hover:text-red-700 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500/40 rounded"
            >
              Sign in as receiver to update status
            </button>
          ) : (
            <span>Click a stage to update in real time</span>
          )}
        </div>
      </div>

      <div
        className={`grid grid-cols-2 ${
          compact ? 'sm:grid-cols-2' : 'sm:grid-cols-4'
        } gap-2`}
      >
        {LIFECYCLE_STAGES.map((stage, idx) => {
          const isCompleted =
            idx < currentIdx || (isLockedClosed && stage.key === 'Closed');
          const isCurrent = idx === currentIdx && !isLockedClosed;
          const isBusy = updatingStage === stage.key;

          let buttonClasses =
            'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50';
          let stateLabel = 'Set';

          if (isLockedClosed) {
            buttonClasses =
              stage.key === 'Closed'
                ? 'border-emerald-200 bg-emerald-50 text-emerald-900 cursor-default'
                : 'border-emerald-200/70 bg-emerald-50/50 text-emerald-800 cursor-default';
            stateLabel = stage.key === 'Closed' ? 'Done' : 'Done';
          } else if (isCurrent) {
            stateLabel = 'Active';
            if (stage.key === 'Open / Broadcasted') {
              buttonClasses =
                'border-red-300 bg-red-50 text-red-900 cursor-default';
            } else if (stage.key === 'Donors Responded') {
              buttonClasses =
                'border-amber-300 bg-amber-50 text-amber-950 cursor-default';
            } else {
              buttonClasses =
                'border-emerald-300 bg-emerald-50 text-emerald-950 cursor-default';
            }
          } else if (isCompleted) {
            stateLabel = 'Done';
            buttonClasses =
              'border-emerald-200 bg-emerald-50/60 text-emerald-800 hover:bg-emerald-50';
          }

          let iconEl = <Radio className="w-3.5 h-3.5 shrink-0" />;
          if (idx === 1) iconEl = <UserCheck className="w-3.5 h-3.5 shrink-0" />;
          if (idx === 2) iconEl = <Truck className="w-3.5 h-3.5 shrink-0" />;
          if (idx === 3) iconEl = <Check className="w-3.5 h-3.5 shrink-0" />;

          if (isBusy) {
            iconEl = <Loader2 className="w-3.5 h-3.5 shrink-0 animate-spin" />;
          } else if (isCompleted) {
            iconEl = <Check className="w-3.5 h-3.5 shrink-0 text-emerald-600" />;
          } else if (isCurrent && stage.key === 'Open / Broadcasted') {
            iconEl = <Clock className="w-3.5 h-3.5 shrink-0 text-red-600" />;
          }

          const isDisabled = isLockedClosed || Boolean(updatingStage);

          return (
            <button
              key={stage.key}
              type="button"
              disabled={isDisabled}
              aria-pressed={isCurrent || (isLockedClosed && stage.key === 'Closed')}
              onClick={() => void handleStageSelect(stage)}
              className={`min-h-[44px] text-left px-3 py-2 rounded-lg border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500/30 ${buttonClasses}`}
            >
              <div className="flex items-center justify-between gap-1.5">
                <span className="inline-flex items-center gap-1.5 text-xs font-semibold truncate">
                  {iconEl}
                  <span className="font-mono-tabular">{idx + 1}.</span>
                  <span className="truncate">{stage.receiverLabel}</span>
                </span>
                <span className="text-[11px] font-medium opacity-80 whitespace-nowrap shrink-0">
                  {isBusy ? 'Saving...' : stateLabel}
                </span>
              </div>
              <p className="mt-0.5 text-[11px] opacity-75 truncate">
                {stage.clinicalLabel}
              </p>
            </button>
          );
        })}
      </div>
    </section>
  );
}
