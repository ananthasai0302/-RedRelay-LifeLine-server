import { LogIn, LogOut, ShieldCheck } from 'lucide-react';
import { useRedRelay } from '../context/RedRelayContext';

export function AuthBar() {
  const { user, authReady, firestoreConnected, signInWithGoogle, signOutUser } =
    useRedRelay();

  return (
    <div className="bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-slate-600">
          <ShieldCheck
            className={`w-3.5 h-3.5 ${
              firestoreConnected ? 'text-emerald-600' : 'text-slate-400'
            }`}
          />
          <span>
            {firestoreConnected
              ? 'Cloud Firestore Sync Active'
              : 'Connecting to Firestore'}
          </span>
          <span className="text-slate-300" aria-hidden="true">
            ·
          </span>
          <span>
            {user
              ? `Verified Account: ${user.displayName ?? user.email}`
              : 'Public Read Mode — Sign in with Google to post SOS or donate'}
          </span>
        </div>

        <div className="shrink-0">
          {!authReady ? (
            <span className="text-slate-400">Checking session...</span>
          ) : user ? (
            <button
              type="button"
              onClick={() => void signOutUser()}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-100 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              Sign Out
            </button>
          ) : (
            <button
              type="button"
              onClick={() => void signInWithGoogle()}
              className="inline-flex items-center gap-1.5 px-3 py-1 font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors"
            >
              <LogIn className="w-3.5 h-3.5" />
              Sign In with Google
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
