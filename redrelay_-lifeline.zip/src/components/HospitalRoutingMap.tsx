import { useEffect, useMemo, useRef, useState } from 'react';
import L from 'leaflet';
import { Navigation, MapPin } from 'lucide-react';
import type {
  BloodGroup,
  BloodRequest,
  Donor,
  DonorResponse,
} from '../types/redrelay';
import { estimateDriveMinutes, haversineDistanceKm } from '../utils/compatibility';

interface MapDonorPoint extends Donor {
  distanceKm: number;
  etaMinutes: number;
  isCommitted: boolean;
}

interface HospitalRoutingMapProps {
  request: BloodRequest;
  allActiveRequests?: BloodRequest[];
  onSelectRequest?: (requestId: string) => void;
  userLocation?: { lat: number; lng: number; label: string };
  eligibleDonors: Array<Donor & { distanceKm: number; etaMinutes: number }>;
  responses: DonorResponse[];
  radiusKm: number;
  heightClass?: string;
}

const BLOOD_TYPE_PIN_STYLES: Record<
  BloodGroup,
  { bg: string; border: string; text: string }
> = {
  'O-': { bg: '#DC2626', border: '#991B1B', text: '#FFFFFF' },
  'O+': { bg: '#EF4444', border: '#B91C1C', text: '#FFFFFF' },
  'A-': { bg: '#1D4ED8', border: '#1E3A8A', text: '#FFFFFF' },
  'A+': { bg: '#2563EB', border: '#1D4ED8', text: '#FFFFFF' },
  'B-': { bg: '#B45309', border: '#78350F', text: '#FFFFFF' },
  'B+': { bg: '#D97706', border: '#92400E', text: '#FFFFFF' },
  'AB-': { bg: '#6D28D9', border: '#4C1D95', text: '#FFFFFF' },
  'AB+': { bg: '#7C3AED', border: '#5B21B6', text: '#FFFFFF' },
};

function buildBloodTypeIcon(
  bloodGroup: BloodGroup,
  isSelected: boolean,
  isCritical: boolean,
  unitsRemaining: number
): L.DivIcon {
  const palette = BLOOD_TYPE_PIN_STYLES[bloodGroup];
  const scale = isSelected ? 'transform:scale(1.14);' : '';
  const ring = isSelected
    ? 'box-shadow:0 0 0 3px #0F172A, 0 4px 10px rgba(15,23,42,0.35);'
    : isCritical
    ? 'box-shadow:0 0 0 2px rgba(220,38,38,0.35), 0 2px 6px rgba(15,23,42,0.28);'
    : 'box-shadow:0 2px 6px rgba(15,23,42,0.25);';

  const html = `
    <div style="display:flex;flex-direction:column;align-items:center;${scale}transition:transform 150ms ease;">
      <div style="display:flex;align-items:center;gap:4px;background:${palette.bg};color:${palette.text};border:2px solid #FFFFFF;outline:1px solid ${palette.border};border-radius:9999px;padding:4px 8px;font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;white-space:nowrap;${ring}">
        <svg width="11" height="13" viewBox="0 0 12 14" fill="none" aria-hidden="true">
          <path d="M6 0.5C6 0.5 11 6.1 11 9.2C11 11.9 8.76 13.5 6 13.5C3.24 13.5 1 11.9 1 9.2C1 6.1 6 0.5 6 0.5Z" fill="rgba(255,255,255,0.92)"/>
        </svg>
        <span>${bloodGroup}</span>
        <span style="opacity:0.85;font-size:10px;">· ${unitsRemaining}u</span>
      </div>
      <div style="width:0;height:0;border-left:5px solid transparent;border-right:5px solid transparent;border-top:6px solid ${palette.border};margin-top:-1px;"></div>
    </div>
  `;

  return L.divIcon({
    className: 'redrelay-blood-marker',
    html,
    iconSize: [78, 34],
    iconAnchor: [39, 34],
  });
}

export function HospitalRoutingMap({
  request,
  allActiveRequests,
  onSelectRequest,
  userLocation,
  eligibleDonors,
  responses,
  radiusKm,
  heightClass = 'h-80',
}: HospitalRoutingMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);
  const [tileError, setTileError] = useState(false);

  const committedIds = useMemo(
    () =>
      new Set(
        responses
          .filter((r) => r.requestId === request.id)
          .map((r) => r.donorId)
      ),
    [responses, request.id]
  );

  const donorPoints: MapDonorPoint[] = useMemo(() => {
    const byId = new Map<string, MapDonorPoint>();
    for (const d of eligibleDonors) {
      byId.set(d.id, {
        ...d,
        isCommitted: committedIds.has(d.id),
      });
    }
    return Array.from(byId.values());
  }, [eligibleDonors, committedIds]);

  const requestsToPlot = useMemo(() => {
    if (allActiveRequests && allActiveRequests.length > 0) {
      const exists = allActiveRequests.some((r) => r.id === request.id);
      return exists ? allActiveRequests : [request, ...allActiveRequests];
    }
    return [request];
  }, [allActiveRequests, request]);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [userLocation?.lat ?? request.lat, userLocation?.lng ?? request.lng],
      zoom: 12,
      zoomControl: true,
      scrollWheelZoom: false,
    });

    const tileLayer = L.tileLayer(
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 18,
      }
    );

    let errorCount = 0;
    tileLayer.on('tileerror', () => {
      errorCount += 1;
      if (errorCount >= 4) {
        setTileError(true);
      }
    });

    tileLayer.addTo(map);
    const layerGroup = L.layerGroup().addTo(map);

    mapRef.current = map;
    layerGroupRef.current = layerGroup;

    return () => {
      map.remove();
      mapRef.current = null;
      layerGroupRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const layerGroup = layerGroupRef.current;
    if (!map || !layerGroup) return;

    layerGroup.clearLayers();
    const boundsPoints: L.LatLngExpression[] = [];

    // 1. User Current Location Marker & Radius Ring (when userLocation is provided)
    if (userLocation) {
      boundsPoints.push([userLocation.lat, userLocation.lng]);

      L.circle([userLocation.lat, userLocation.lng], {
        radius: radiusKm * 1000,
        color: '#2563EB',
        weight: 1.5,
        opacity: 0.4,
        fillColor: '#2563EB',
        fillOpacity: 0.04,
        dashArray: '5 5',
      }).addTo(layerGroup);

      const userIcon = L.divIcon({
        className: 'redrelay-user-pin',
        html: `<div style="display:flex;align-items:center;gap:5px;background:#0F172A;color:#FFFFFF;padding:4px 9px;border-radius:9999px;font-family:'Plus Jakarta Sans',sans-serif;font-size:11px;font-weight:700;white-space:nowrap;border:2px solid #3B82F6;box-shadow:0 2px 8px rgba(37,99,235,0.45);">
          <span style="width:7px;height:7px;border-radius:9999px;background:#60A5FA;display:inline-block;"></span>
          You
        </div>`,
        iconSize: [58, 26],
        iconAnchor: [29, 13],
      });

      L.marker([userLocation.lat, userLocation.lng], { icon: userIcon })
        .bindPopup(
          `<div style="font-family:'DM Sans',sans-serif;min-width:150px;">
            <div style="font-weight:700;color:#0F172A;font-size:12px;">Your Current Location</div>
            <div style="color:#475569;font-size:11px;margin-top:2px;">${userLocation.label}</div>
            <div style="color:#2563EB;font-size:11px;margin-top:3px;font-family:'JetBrains Mono',monospace;">${userLocation.lat.toFixed(4)}, ${userLocation.lng.toFixed(4)}</div>
          </div>`
        )
        .addTo(layerGroup);
    } else {
      // Hospital-centered radius ring when no userLocation passed
      L.circle([request.lat, request.lng], {
        radius: radiusKm * 1000,
        color: '#DC2626',
        weight: 1.5,
        opacity: 0.45,
        fillColor: '#DC2626',
        fillOpacity: 0.05,
        dashArray: '4 4',
      }).addTo(layerGroup);
    }

    // 2. Plot ALL Active Emergency Requests with Custom Blood-Type Icons
    for (const reqItem of requestsToPlot) {
      const isSelected = reqItem.id === request.id;
      const unitsRemaining = Math.max(
        1,
        reqItem.unitsNeeded - reqItem.unitsCommitted
      );
      const distFromUser = userLocation
        ? haversineDistanceKm(
            userLocation.lat,
            userLocation.lng,
            reqItem.lat,
            reqItem.lng
          )
        : null;
      const etaFromUser =
        distFromUser !== null ? estimateDriveMinutes(distFromUser) : null;

      boundsPoints.push([reqItem.lat, reqItem.lng]);

      // Sightline vector from User Location -> Active SOS Request
      if (userLocation) {
        L.polyline(
          [
            [userLocation.lat, userLocation.lng],
            [reqItem.lat, reqItem.lng],
          ],
          {
            color: isSelected ? '#DC2626' : '#94A3B8',
            weight: isSelected ? 2.5 : 1,
            opacity: isSelected ? 0.85 : 0.35,
            dashArray: isSelected ? undefined : '4 5',
          }
        ).addTo(layerGroup);
      }

      const icon = buildBloodTypeIcon(
        reqItem.bloodGroup,
        isSelected,
        reqItem.urgencyLevel === 'Critical',
        unitsRemaining
      );

      const marker = L.marker([reqItem.lat, reqItem.lng], { icon })
        .bindPopup(
          `<div style="font-family:'DM Sans',sans-serif;min-width:190px;">
            <div style="font-weight:700;color:#0F172A;font-size:13px;">${reqItem.hospitalName}</div>
            <div style="color:#475569;font-size:11px;margin-top:2px;">${reqItem.id} · ${reqItem.locality}, ${reqItem.city}</div>
            <div style="color:#DC2626;font-weight:700;font-size:11px;margin-top:4px;">Needs ${reqItem.unitsNeeded - reqItem.unitsCommitted} unit(s) · ${reqItem.bloodGroup} (${reqItem.bloodKind})</div>
            ${
              distFromUser !== null
                ? `<div style="color:#2563EB;font-weight:600;font-size:11px;margin-top:3px;">${distFromUser} km from you (~${etaFromUser} min drive)</div>`
                : ''
            }
          </div>`
        )
        .addTo(layerGroup);

      if (onSelectRequest) {
        marker.on('click', () => {
          onSelectRequest(reqItem.id);
        });
      }
    }

    // 3. Plot Eligible & Committed Donor Pins for the Selected Request
    for (const donor of donorPoints) {
      boundsPoints.push([donor.lat, donor.lng]);

      const bgColor = donor.isCommitted ? '#16A34A' : '#0F172A';
      const borderColor = donor.isCommitted ? '#BBF7D0' : '#E2E8F0';

      const donorIcon = L.divIcon({
        className: 'redrelay-donor-pin',
        html: `<div style="background:${bgColor};color:#fff;padding:2px 6px;border-radius:4px;font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:600;white-space:nowrap;border:1px solid ${borderColor};box-shadow:0 1px 4px rgba(0,0,0,0.2);">${donor.initials} ${donor.bloodGroup}</div>`,
        iconSize: [72, 22],
        iconAnchor: [36, 11],
      });

      L.polyline(
        [
          [donor.lat, donor.lng],
          [request.lat, request.lng],
        ],
        {
          color: donor.isCommitted ? '#16A34A' : '#CBD5E1',
          weight: donor.isCommitted ? 2.5 : 1,
          opacity: donor.isCommitted ? 0.9 : 0.45,
          dashArray: donor.isCommitted ? undefined : '3 4',
        }
      ).addTo(layerGroup);

      L.marker([donor.lat, donor.lng], { icon: donorIcon })
        .bindPopup(
          `<div style="font-family:'DM Sans',sans-serif;min-width:165px;">
            <div style="font-weight:700;color:#0F172A;font-size:12px;">Donor ${donor.initials} (${donor.bloodGroup})</div>
            <div style="color:#475569;font-size:11px;margin-top:2px;">${donor.locality} · ${donor.maskedPhone}</div>
            <div style="color:${donor.isCommitted ? '#16A34A' : '#0F172A'};font-weight:600;font-size:11px;margin-top:4px;">
              ${donor.distanceKm} km · ~${donor.etaMinutes} min to hospital ${donor.isCommitted ? '· Committed' : ''}
            </div>
          </div>`
        )
        .addTo(layerGroup);
    }

    if (boundsPoints.length > 1) {
      map.fitBounds(L.latLngBounds(boundsPoints), {
        padding: [42, 42],
        maxZoom: 13,
      });
    } else {
      map.setView([request.lat, request.lng], 12);
    }

    window.setTimeout(() => {
      map.invalidateSize();
    }, 120);
  }, [
    request,
    requestsToPlot,
    userLocation,
    donorPoints,
    radiusKm,
    onSelectRequest,
  ]);

  const committedRouteCards = useMemo(() => {
    return responses
      .filter((r) => r.requestId === request.id)
      .map((r) => {
        const dist =
          r.distanceKm ||
          haversineDistanceKm(request.lat, request.lng, request.lat, request.lng);
        return {
          ...r,
          distanceKm: dist,
          etaMinutes: r.etaMinutes || estimateDriveMinutes(dist),
        };
      });
  }, [responses, request]);

  const userDistToSelected = userLocation
    ? haversineDistanceKm(
        userLocation.lat,
        userLocation.lng,
        request.lat,
        request.lng
      )
    : null;

  return (
    <div className="space-y-3">
      <div
        className={`relative w-full ${heightClass} rounded-xl border border-slate-200 overflow-hidden bg-slate-100`}
      >
        <div ref={containerRef} className="w-full h-full" />

        {tileError && (
          <div className="absolute inset-0 bg-slate-50/95 flex flex-col items-center justify-center p-4 text-center z-20">
            <MapPin className="w-6 h-6 text-red-600 mb-2" />
            <p className="text-sm font-semibold text-slate-900">
              {request.hospitalName} ({request.locality})
            </p>
            <p className="text-xs text-slate-600 mt-1 max-w-md">
              Map tiles unavailable offline. Spatial transit calculations remain
              active for {requestsToPlot.length} emergency request(s) and{' '}
              {donorPoints.length} compatible donor(s).
            </p>
          </div>
        )}

        <div className="absolute bottom-2.5 left-2.5 z-20 bg-white/95 backdrop-blur-sm border border-slate-200 rounded-lg px-2.5 py-1.5 text-[11px] text-slate-700 flex flex-wrap items-center gap-x-2.5 gap-y-1 shadow-sm">
          {userLocation && (
            <>
              <span className="font-semibold text-blue-700">You = Current Location</span>
              <span className="text-slate-300">|</span>
            </>
          )}
          <span className="font-semibold text-red-600">O = Crimson</span>
          <span className="font-semibold text-blue-600">A = Blue</span>
          <span className="font-semibold text-amber-700">B = Amber</span>
          <span className="font-semibold text-violet-700">AB = Violet</span>
          <span className="text-slate-300">|</span>
          <span className="font-medium text-emerald-700">Green = Committed Donor</span>
        </div>
      </div>

      {/* Driving transit ETA strip */}
      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
        <span className="inline-flex items-center gap-1.5 font-medium text-slate-800">
          <Navigation className="w-3.5 h-3.5 text-slate-500" />
          Transit Estimates:
        </span>
        {userDistToSelected !== null && (
          <span className="font-mono-tabular text-xs text-blue-800 bg-blue-50 border border-blue-200 rounded-md px-2 py-0.5">
            From You → {request.hospitalName.split(',')[0]}: {userDistToSelected} km · ~
            {estimateDriveMinutes(userDistToSelected)} min
          </span>
        )}
        {committedRouteCards.length > 0 ? (
          committedRouteCards.map((resp) => (
            <span
              key={resp.id}
              className="font-mono-tabular text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-md px-2 py-0.5"
            >
              {resp.donorInitials} ({resp.donorBloodGroup}) · {resp.distanceKm} km · ~
              {resp.etaMinutes} min
            </span>
          ))
        ) : donorPoints.length > 0 ? (
          donorPoints.slice(0, 3).map((d) => (
            <span
              key={d.id}
              className="font-mono-tabular text-xs text-slate-700 bg-white border border-slate-200 rounded-md px-2 py-0.5"
            >
              Nearest {d.initials} ({d.bloodGroup}) · {d.distanceKm} km · ~
              {d.etaMinutes} min
            </span>
          ))
        ) : (
          <span className="text-slate-500">
            No compatible donors within {radiusKm} km radius.
          </span>
        )}
      </div>
    </div>
  );
}
