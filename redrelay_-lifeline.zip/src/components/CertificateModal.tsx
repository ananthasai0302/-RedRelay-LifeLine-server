import { useEffect, useState } from 'react';
import { Download, X, Award } from 'lucide-react';
import {
  downloadCertificatePng,
  renderCertificateDataUrl,
  type CertificateDetails,
} from '../utils/certificateGenerator';

interface CertificateModalProps {
  details: CertificateDetails | null;
  onClose: () => void;
}

export function CertificateModal({ details, onClose }: CertificateModalProps) {
  const [previewUrl, setPreviewUrl] = useState<string>('');

  useEffect(() => {
    if (!details) {
      setPreviewUrl('');
      return;
    }
    setPreviewUrl(renderCertificateDataUrl(details));
  }, [details]);

  if (!details) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="cert-modal-title"
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="bg-white border border-slate-200 rounded-xl max-w-3xl w-full overflow-hidden shadow-2xl">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <Award className="w-5 h-5 text-red-600" />
            <h2
              id="cert-modal-title"
              className="text-base font-bold text-slate-900"
            >
              Digital Donor Appreciation Certificate
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close certificate preview"
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 bg-slate-50">
          {previewUrl ? (
            <img
              src={previewUrl}
              alt={`RedRelay Donor Appreciation Certificate for ${details.donorName}`}
              className="w-full h-auto rounded-lg border border-slate-200 bg-white"
            />
          ) : (
            <div className="h-64 flex items-center justify-center text-sm text-slate-500">
              Rendering certificate preview...
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-slate-200 bg-white flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-slate-500">
            Issued for verified emergency fulfillment {details.requestId} ·{' '}
            <span className="font-mono-tabular">{details.certificateId}</span>
          </p>
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50"
            >
              Close
            </button>
            <button
              type="button"
              onClick={() => downloadCertificatePng(details)}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700"
            >
              <Download className="w-4 h-4" />
              Download PNG Badge
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
