import { useEffect, useMemo, useRef, useState } from 'react';
import { Check, ChevronDown, Search, ShieldCheck, X } from 'lucide-react';

export interface SearchableDropdownOption {
  value: string;
  label: string;
  sublabel?: string;
  metricText?: string;
  metricTone?: 'positive' | 'warning' | 'muted';
  searchKeywords?: string;
  isEligible?: boolean;
}

export interface SearchableDropdownProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: SearchableDropdownOption[];
  placeholder?: string;
  searchPlaceholder?: string;
  emptyText?: string;
  policyFilterLabel?: string;
  policyFilterActive?: boolean;
  onTogglePolicyFilter?: (next: boolean) => void;
  helperText?: string;
}

export function SearchableDropdown({
  id,
  label,
  value,
  onChange,
  options,
  placeholder = 'Select an option...',
  searchPlaceholder = 'Type to search...',
  emptyText = 'No matching options found.',
  policyFilterLabel,
  policyFilterActive = false,
  onTogglePolicyFilter,
  helperText,
}: SearchableDropdownProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const containerRef = useRef<HTMLDivElement | null>(null);
  const searchInputRef = useRef<HTMLInputElement | null>(null);

  const selectedOption = useMemo(
    () => options.find((opt) => opt.value === value) ?? null,
    [options, value]
  );

  useEffect(() => {
    if (!open) return;
    const timer = window.setTimeout(() => {
      searchInputRef.current?.focus();
    }, 20);

    const handleOutsideClick = (event: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setOpen(false);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setOpen(false);
      }
    };

    document.addEventListener('mousedown', handleOutsideClick);
    document.addEventListener('keydown', handleEscape);
    return () => {
      window.clearTimeout(timer);
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [open]);

  const filteredOptions = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return options.filter((opt) => {
      if (policyFilterActive && opt.isEligible === false) {
        return false;
      }
      if (!normalized) return true;
      const haystack = `${opt.label} ${opt.sublabel ?? ''} ${opt.searchKeywords ?? ''}`.toLowerCase();
      return haystack.includes(normalized);
    });
  }, [options, query, policyFilterActive]);

  const hiddenByPolicyCount = useMemo(() => {
    if (!policyFilterActive) return 0;
    return options.filter((opt) => opt.isEligible === false).length;
  }, [options, policyFilterActive]);

  const getMetricToneClass = (tone?: SearchableDropdownOption['metricTone']) => {
    if (tone === 'positive') return 'text-emerald-700';
    if (tone === 'warning') return 'text-amber-700';
    return 'text-slate-500';
  };

  return (
    <div ref={containerRef} className="relative space-y-1.5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <label
          htmlFor={id}
          className="block text-xs font-semibold text-slate-700"
        >
          {label}
        </label>
        {helperText && (
          <span className="text-[11px] text-slate-500">{helperText}</span>
        )}
      </div>

      <button
        id={id}
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen((prev) => !prev)}
        className={`w-full px-3.5 py-2.5 text-left bg-white border rounded-lg transition-colors flex items-center justify-between gap-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500/25 ${
          open
            ? 'border-red-500 ring-2 ring-red-500/15'
            : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        <div className="min-w-0 flex-1">
          {selectedOption ? (
            <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-0.5">
              <div className="min-w-0">
                <span className="text-sm font-semibold text-slate-950 truncate block">
                  {selectedOption.label}
                </span>
                {selectedOption.sublabel && (
                  <span className="text-xs text-slate-500 truncate block">
                    {selectedOption.sublabel}
                  </span>
                )}
              </div>
              {selectedOption.metricText && (
                <span
                  className={`text-xs font-mono-tabular font-semibold shrink-0 ${getMetricToneClass(
                    selectedOption.metricTone
                  )}`}
                >
                  {selectedOption.metricText}
                </span>
              )}
            </div>
          ) : (
            <span className="text-sm text-slate-400">{placeholder}</span>
          )}
        </div>
        <ChevronDown
          className={`w-4 h-4 text-slate-500 shrink-0 transition-transform ${
            open ? 'rotate-180' : ''
          }`}
        />
      </button>

      {open && (
        <div className="absolute left-0 right-0 z-30 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden">
          <div className="p-2.5 border-b border-slate-100 space-y-2 bg-slate-50/70">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                ref={searchInputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={searchPlaceholder}
                className="w-full pl-8 pr-8 py-2 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
              />
              {query && (
                <button
                  type="button"
                  aria-label="Clear search"
                  onClick={() => setQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {onTogglePolicyFilter && policyFilterLabel && (
              <div className="flex items-center justify-between gap-2 px-1">
                <label className="inline-flex items-center gap-2 text-[11px] font-medium text-slate-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={policyFilterActive}
                    onChange={(e) => onTogglePolicyFilter(e.target.checked)}
                    className="rounded border-slate-300 text-red-600 focus:ring-red-500"
                  />
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>{policyFilterLabel}</span>
                </label>
                {hiddenByPolicyCount > 0 && (
                  <span className="text-[11px] font-mono-tabular text-amber-700 shrink-0">
                    {hiddenByPolicyCount} filtered (90d lock)
                  </span>
                )}
              </div>
            )}
          </div>

          <ul
            role="listbox"
            aria-labelledby={id}
            className="max-h-64 overflow-y-auto divide-y divide-slate-100"
          >
            {filteredOptions.length === 0 ? (
              <li className="px-4 py-6 text-center space-y-2">
                <p className="text-xs text-slate-500">{emptyText}</p>
                {policyFilterActive && onTogglePolicyFilter && (
                  <button
                    type="button"
                    onClick={() => onTogglePolicyFilter(false)}
                    className="text-xs font-semibold text-red-600 hover:underline"
                  >
                    Show all options (including 0 unlocked matches)
                  </button>
                )}
              </li>
            ) : (
              filteredOptions.map((opt) => {
                const isSelected = opt.value === value;
                return (
                  <li key={opt.value}>
                    <button
                      type="button"
                      role="option"
                      aria-selected={isSelected}
                      onClick={() => {
                        onChange(opt.value);
                        setOpen(false);
                        setQuery('');
                      }}
                      className={`w-full px-3.5 py-2.5 text-left flex items-center justify-between gap-3 transition-colors ${
                        isSelected
                          ? 'bg-red-50/80 text-slate-950'
                          : 'hover:bg-slate-50 text-slate-800'
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs sm:text-sm font-semibold truncate">
                            {opt.label}
                          </span>
                          {isSelected && (
                            <Check className="w-3.5 h-3.5 text-red-600 shrink-0" />
                          )}
                        </div>
                        {opt.sublabel && (
                          <p className="text-[11px] text-slate-500 truncate mt-0.5">
                            {opt.sublabel}
                          </p>
                        )}
                      </div>

                      {opt.metricText && (
                        <span
                          className={`text-[11px] font-mono-tabular font-semibold shrink-0 text-right ${getMetricToneClass(
                            opt.metricTone
                          )}`}
                        >
                          {opt.metricText}
                        </span>
                      )}
                    </button>
                  </li>
                );
              })
            )}
          </ul>
        </div>
      )}
    </div>
  );
}
