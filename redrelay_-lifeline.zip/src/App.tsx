/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Download } from 'lucide-react';
import { RedRelayProvider } from './context/RedRelayContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Navbar } from './components/Navbar';
import { AuthBar } from './components/AuthBar';
import { ToastContainer } from './components/ToastContainer';
import { ClinicalAssistantDrawer } from './components/ClinicalAssistantDrawer';
import { BroadcastFeedPage } from './pages/BroadcastFeedPage';
import { PostSosPage } from './pages/PostSosPage';
import { DonorPortalPage } from './pages/DonorPortalPage';
import { DonorRegistryPage } from './pages/DonorRegistryPage';
import { RoutingDispatchPage } from './pages/RoutingDispatchPage';

function FooterZipExportButton() {
  const [downloading, setDownloading] = useState(false);

  const handleDownloadZip = async () => {
    if (downloading) return;
    setDownloading(true);
    try {
      const response = await fetch('/api/export-zip');
      if (!response.ok) {
        throw new Error(`Export failed (${response.status})`);
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'redrelay-lifeline.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('ZIP export failed:', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <button
      type="button"
      onClick={() => void handleDownloadZip()}
      disabled={downloading}
      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 disabled:opacity-60 transition-colors whitespace-nowrap shrink-0"
    >
      <Download className="w-3.5 h-3.5 text-slate-600" />
      {downloading ? 'Preparing ZIP...' : 'Download Project ZIP'}
    </button>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <RedRelayProvider>
        <BrowserRouter>
          <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-slate-900">
            <Navbar />
            <AuthBar />

            <main className="flex-1">
              <Routes>
                <Route path="/" element={<BroadcastFeedPage />} />
                <Route path="/post-sos" element={<PostSosPage />} />
                <Route path="/donor-portal" element={<DonorPortalPage />} />
                <Route path="/registry" element={<DonorRegistryPage />} />
                <Route path="/dispatch" element={<RoutingDispatchPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>

            <footer className="border-t border-slate-200 bg-white mt-12">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
                <span>
                  RedRelay: LifeLine · Emergency Blood Coordination & Privacy Relay
                </span>
                <div className="flex flex-wrap items-center gap-4">
                  <span>
                    Clinical ABO/Rh Matrix · 90-Day Recovery Standard · Cloud Firestore Sync
                  </span>
                  <FooterZipExportButton />
                </div>
              </div>
            </footer>

            <ToastContainer />
            <ClinicalAssistantDrawer />
          </div>
        </BrowserRouter>
      </RedRelayProvider>
    </ErrorBoundary>
  );
}
