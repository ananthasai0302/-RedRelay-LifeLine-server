export type BloodGroup =
  | 'O-'
  | 'O+'
  | 'A-'
  | 'A+'
  | 'B-'
  | 'B+'
  | 'AB-'
  | 'AB+';

export type BloodKind =
  | 'Whole Blood'
  | 'Packed Red Blood Cells (PRBC)'
  | 'Platelets'
  | 'Fresh Frozen Plasma (FFP)';

export type RequestStatus =
  | 'Open / Broadcasted'
  | 'Donors Responded'
  | 'Fulfilled / In Transit'
  | 'Closed';

export type UrgencyLevel = 'Critical' | 'Urgent' | 'Standard';

export interface CityLocality {
  city: string;
  locality: string;
  lat: number;
  lng: number;
}

export interface HospitalLocation {
  id: string;
  name: string;
  city: string;
  locality: string;
  address: string;
  lat: number;
  lng: number;
}

export interface UserPrivateProfile {
  uid: string;
  fullName: string;
  email: string;
  phone: string;
  maskedPhone: string;
}

export interface Donor {
  id: string;
  ownerUid: string;
  fullName: string;
  displayName: string;
  initials: string;
  bloodGroup: BloodGroup;
  city: string;
  locality: string;
  lat: number;
  lng: number;
  /** Masked representation safe for public display */
  maskedPhone: string;
  /** Internal relay token */
  relayCode: string;
  isAvailable: boolean;
  lastDonationDate: string | null;
  lockedUntil: string | null;
  totalDonations: number;
  totalUnitsGiven: number;
  verified: boolean;
}

export interface BloodRequest {
  id: string;
  creatorUid: string;
  patientName: string;
  hospitalId: string;
  hospitalName: string;
  city: string;
  locality: string;
  lat: number;
  lng: number;
  bloodGroup: BloodGroup;
  bloodKind: BloodKind;
  unitsNeeded: number;
  unitsCommitted: number;
  urgencyLevel: UrgencyLevel;
  deadlineHours: number;
  expiresAt: string;
  doctorContact: string;
  clinicalNotes: string;
  status: RequestStatus;
  createdAt: string;
  closedAt: string | null;
}

export interface DonorResponse {
  id: string;
  requestId: string;
  donorId: string;
  donorUid: string;
  donorInitials: string;
  donorBloodGroup: BloodGroup;
  donorLocality: string;
  distanceKm: number;
  etaMinutes: number;
  unitsCommitted: number;
  status: 'Committed' | 'In Transit' | 'Donated';
  createdAt: string;
}

export interface SmsDispatchLog {
  id: string;
  requestId: string;
  senderUid: string;
  hospitalName: string;
  bloodGroup: BloodGroup;
  donorId: string;
  donorInitials: string;
  donorBloodGroup: BloodGroup;
  maskedPhone: string;
  distanceKm: number;
  messagePreview: string;
  deliveryStatus: 'Delivered' | 'Queued';
  sentAt: string;
}
