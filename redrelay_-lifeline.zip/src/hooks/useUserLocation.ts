import { useCallback, useEffect, useState } from 'react';
import { LOCALITIES } from '../data/seedData';

export interface UserLocationState {
  lat: number;
  lng: number;
  source: 'gps' | 'manual';
  label: string;
  status: 'locating' | 'ready' | 'denied';
}

export function useUserLocation() {
  const [location, setLocation] = useState<UserLocationState>({
    lat: 17.4156,
    lng: 78.4347,
    source: 'manual',
    label: 'Banjara Hills, Hyderabad, Telangana (Default Hub)',
    status: 'locating',
  });

  const refreshGps = useCallback(() => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setLocation((prev) => ({
        ...prev,
        status: 'denied',
      }));
      return;
    }

    setLocation((prev) => ({ ...prev, status: 'locating' }));
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({
          lat: Math.round(pos.coords.latitude * 10000) / 10000,
          lng: Math.round(pos.coords.longitude * 10000) / 10000,
          source: 'gps',
          label: 'Live Device GPS',
          status: 'ready',
        });
      },
      () => {
        setLocation((prev) => ({
          ...prev,
          source: 'manual',
          status: 'denied',
        }));
      },
      {
        enableHighAccuracy: true,
        timeout: 6000,
        maximumAge: 60000,
      }
    );
  }, []);

  useEffect(() => {
    refreshGps();
  }, [refreshGps]);

  const setManualLocality = useCallback((localityName: string) => {
    const match = LOCALITIES.find((l) => l.locality === localityName);
    if (!match) return;
    setLocation({
      lat: match.lat,
      lng: match.lng,
      source: 'manual',
      label: `${match.locality}, ${match.city}`,
      status: 'ready',
    });
  }, []);

  return {
    location,
    refreshGps,
    setManualLocality,
  };
}
