# RedRelay Firestore Security Specification (Phase 0)

## Data Invariants
1. **PII Isolation**: Raw donor phone numbers and emails reside strictly under `/users/{userId}/private/profile` and are never readable by non-owners.
2. **Identity Integrity**: Every write requires `request.auth != null && request.auth.token.email_verified == true`. Creators/owners cannot spoof another user's UID (`ownerUid`, `creatorUid`, `donorUid`, `senderUid`).
3. **Referential Integrity**: Every `/responses/{responseId}` and `/smsLogs/{logId}` document verifies `exists()` on the referenced `/requests/{requestId}` document.
4. **Terminal State Locking**: Once a `/requests/{requestId}` reaches `status == 'Closed'`, no non-admin updates are permitted. Once a `/responses/{responseId}` reaches `status == 'Donated'`, no non-admin updates are permitted.
5. **Temporal Integrity**: `createdAt`, `updatedAt`, and `sentAt` timestamps on write must match `request.time`.

## Dirty Dozen Attack Payloads (Expected: PERMISSION_DENIED)
1. Unauthenticated read on `/users/{uid}/private/profile` -> DENIED.
2. Authenticated non-owner read (`get`) on `/users/{otherUid}/private/profile` -> DENIED.
3. Unverified email user (`email_verified: false`) attempting `create` on `/requests/{id}` -> DENIED.
4. UID spoofing: User A creating `/donors/{id}` with `ownerUid: 'user-B'` -> DENIED.
5. Shadow field injection: Creating `/donors/{id}` with unexpected field `isAdmin: true` -> DENIED via `hasOnly()`.
6. ID poisoning: Creating `/requests/{1500-char-id}` -> DENIED via `isValidId()`.
7. Client timestamp spoofing: Creating `/requests/{id}` with backdated `createdAt` -> DENIED via `request.time`.
8. Immutable field tampering: Updating `creatorUid` or `createdAt` on `/requests/{id}` -> DENIED.
9. Terminal state bypass: Updating a `Closed` request back to `Open / Broadcasted` -> DENIED.
10. Orphaned response injection: Creating `/responses/{id}` referencing a non-existent `requestId` -> DENIED via `exists()`.
11. Cross-user list scraping: Listing `/smsLogs` without matching `senderUid == request.auth.uid` (non-admin) -> DENIED.
12. Value poisoning: Updating `/requests/{id}` `unitsCommitted` to `999` (`> unitsNeeded`) or negative -> DENIED.
