# RedRelay: LifeLine — Maps, Geolocation, Firebase & Grounding Upgrade

RedRelay is being upgraded from browser-only storage to a full-stack, cloud-persisted emergency blood coordination platform featuring multi-request spatial mapping relative to the user's live GPS location (with custom blood-type icons on both Leaflet and Google Maps Platform), Firebase Google Sign-In and Firestore persistence, and server-side Gemini Maps Grounding for nearby verified blood banks and trauma centers.

### User Review & Critical Decisions

> [!IMPORTANT]
> Because the Phase 1 clarifying questions were skipped, the recommended defaults below have been selected. Provisioning prompts for Firebase and Google Maps Platform will appear for your confirmation immediately after you approve this plan.

- **Dual Interactive Map Engine on Routing & Dispatch (`Leaflet` + `Google Maps`)**: `RoutingDispatchPage` will offer a segmented **Leaflet (OpenStreetMap)** / **Google Maps Platform** toggle. Both views plot **all active emergency SOS requests simultaneously relative to the user's live GPS location**, using **custom distinct blood-type icons** (`O-`, `O+`, `A-`, `A+`, `B-`, `B+`, `AB-`, `AB+`) and proximity vectors from the user to each hospital.
- **Firebase Auth & Cloud Firestore Persistence**: Users can browse the live SOS broadcast feed immediately, while **Google Sign-In (Firebase Auth)** unlocks posting verified SOS requests, committing `I Can Donate` units, marking blood received, and managing private donor profiles in Firestore. Donor phone numbers and emails are strictly isolated in owner-only private subcollections.
- **User Geolocation & Gemini Maps Grounding (`gemini-4-hydrogen`)**: Browser `navigator.geolocation` (with a manual city/coordinate fallback) anchors the user's position on the map, sorts active SOS requests by real distance from the user, and powers a server-side Express `/api/maps/grounding` endpoint using `gemini-4-hydrogen` with the `googleMaps` tool to surface grounded links to nearby blood banks and hospitals.

---

### 1. Overview & Core Concept

- **What Changes**:
  - Upgrades `RoutingDispatchPage` from a single-request map into a **live multi-SOS spatial command map** centered around the user's current GPS position, showing all active emergency requests with custom blood-type icons, distance/ETA rings, and click-to-inspect routing lines.
  - Migrates persistence from `localStorage`-only to **Cloud Firestore** with real-time `onSnapshot` listeners, authenticated via **Firebase Google Sign-In**, backed by hardened `firestore.rules` and a `firebase-blueprint.json` schema.
  - Introduces a lightweight **Express + Vite full-stack server (`server.ts`)** to securely host the `gemini-4-hydrogen` Maps Grounding API route without exposing `GEMINI_API_KEY` to the browser.
- **Target Audience / Persona**:
  - **Voluntary Donors on the Move**: Immediately see every nearby active blood request relative to their live GPS location, visually color- and icon-coded by blood type (`O-`, `B+`, etc.), and filterable by biological compatibility.
  - **Hospital Coordinators & Families**: Authenticate with Google Sign-In to publish persistent, real-time SOS broadcasts visible across devices, dispatch simulated SMS alerts, and look up grounded nearby blood banks via Gemini Maps Grounding.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **User Location & Multi-Request Blood-Type Map (`RoutingDispatchPage`)**:
     - On arrival, the page requests browser geolocation (`navigator.geolocation`) and displays a **User Location** beacon alongside a manual locality fallback (`Bengaluru`, `Mumbai`, `Delhi`) so the map always works even if GPS permission is denied.
     - **Custom Blood-Type Icons**: Every active SOS request renders as a distinct custom icon displaying its blood group (`O-`, `O+`, `A-`, `A+`, `B-`, `B+`, `AB-`, `AB+`), urgency indicator, and units needed—color-coded by ABO/Rh group family (e.g., O-group crimson, A-group sapphire, B-group amber, AB-group violet) with clear text labels for color-blind accessibility.
     - **Toggleable Engine (`Leaflet` | `Google Maps`)**: Users can switch seamlessly between Leaflet (with custom `L.divIcon` blood-type badges, distance polylines from the user's current location, and OpenStreetMap tiles) and Google Maps Platform (`@vis.gl/react-google-maps` with `AdvancedMarkerElement`, `PinElement` / custom blood-type HTML badges, and `Route.computeRoutes()` transit estimates).
     - Clicking any blood-type marker selects that SOS request, draws the direct transit vector from the user's location (plus nearby eligible donor pins), and updates the SMS Dispatch Simulator panel.
  2. **Gemini Maps Grounding Lookup (`RoutingDispatchPage`)**:
     - A **Nearby Blood Banks & Hospitals** grounding drawer queries `/api/maps/grounding` with the user's live `latLng` and optional clinical query (e.g., "24-hour blood banks and trauma centers near me").
     - Displays grounded Markdown guidance and mandatory clickable **Google Maps place links** extracted from `groundingChunks.maps.uri` and `placeAnswerSources`.
  3. **Firebase Google Sign-In & Cloud Sync**:
     - A clean sign-in button in the page toolbar / action bar lets users sign in via `signInWithPopup` (Google Auth).
     - Authenticated donors and coordinators sync requests, donor profiles, responses, and SMS dispatch logs in real time across sessions via Firestore `onSnapshot` subscriptions, with structured permission/offline error boundaries.

- **Visual Identity & Theme**:
  - Preserves the **High-Contrast Clinical Light Mode** (`#F8FAFC` canvas, `#FFFFFF` bordered surfaces, `#DC2626` surgical crimson primary accents, `Plus Jakarta Sans` + `DM Sans` + `JetBrains Mono` tabular numerals).
  - Maintains the strict **3-zone Top Bar Contract** (`RedRelay` wordmark — 4 navigation links — `Post Emergency SOS` CTA), placing the Google Sign-In account chip and map controls inside the page workspace rather than crowding the header.
  - Zero-pill metadata discipline (`·` separators, crisp square blood-type tags, no nested card shadows).

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual Map Support (`Leaflet` + `Google Maps Platform`) on `RoutingDispatchPage`**
  - *Chosen Approach*: Keep and upgrade Leaflet on `RoutingDispatchPage` to display all active SOS requests relative to the user's live GPS coordinates with custom blood-type icons, AND pair it via a clean segmented toggle with `@vis.gl/react-google-maps` (`AdvancedMarkerElement` + `Routes` API).
  - *Why*: Directly satisfies both the explicit prompt instruction ("Integrate Leaflet into the RoutingDispatchPage...") and the attached Google Maps Platform requirement while adhering to modern Maps JS standards (`AdvancedMarkerElement`, `Route.computeRoutes()`, and `internalUsageAttributionIds={["gmp_mcp_codeassist_v1_aistudio"]}`).

- **Decision 2: Full-Stack Express Server (`server.ts`) for Gemini Maps Grounding**
  - *Chosen Approach*: Run Express with `vite.middlewares` on port 3000 (`tsx server.ts`) exposing `POST /api/maps/grounding` using `@google/genai` (`gemini-4-hydrogen`, `tools: [{ googleMaps: {} }]`).
  - *Why*: Keeps `GEMINI_API_KEY` strictly server-side while passing the user's browser `latLng` in `toolConfig.retrievalConfig.latLng` and returning `groundingChunks` URIs to the React UI.

- **Decision 3: Firestore Split-Collection PII Isolation & Hardened Rules**
  - *Chosen Approach*: Store public-safe donor summaries (`initials`, `bloodGroup`, `locality`, `lat`, `lng`, `maskedPhone`, `isAvailable`, `lockedUntil`) in `/donors/{donorId}`, while isolating sensitive personal contact data (`fullName`, `rawPhone`, `email`) in `/users/{uid}/private/profile` readable strictly by the owner (`request.auth.uid == uid`). Public reads are enabled on `/requests` and `/donors` (non-PII), while writes require verified Firebase Google Sign-In (`request.auth.token.email_verified == true`), strict key validation (`hasOnly`), and server-validated transitions.
  - *Why*: Enforces zero phone-number leakage at the database security-rule level, not just in UI presentation.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                    Express + Vite Server (server.ts :3000)              │
│  • Serves Vite SPA          • POST /api/maps/grounding (gemini-4-hydrogen│
│                               with { googleMaps: {} } & user latLng)    │
└───────────────┬─────────────────────────────────────────┬───────────────┘
                │ HTTP JSON + Grounding Chunks            │ Static / Dev SPA
┌───────────────▼─────────────────────────────────────────▼───────────────┐
│                     React Client Application                            │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │ Firebase SDK (Auth Google Popup + Firestore Realtime Listeners)   │  │
│  │ • /requests   • /donors (public safe)   • /users/{uid}/private    │  │
│  │ • /responses  • /smsLogs                • testConnection() check  │  │
│  └───────────────────────────────┬───────────────────────────────────┘  │
│                                  │                                      │
│  ┌───────────────────────────────▼───────────────────────────────────┐  │
│  │ RoutingDispatchPage (User Geolocation + Multi-SOS Spatial View)   │  │
│  │  • Leaflet Map (Custom Blood-Type L.divIcon + User GPS Vectors)   │  │
│  │  • Google Maps (@vis.gl/react-google-maps AdvancedMarkerElement)  │  │
│  │  • Nearby Grounded Blood Banks Panel (Maps Grounding URIs)        │  │
│  │  • SMS SOS Dispatch Simulator Console                             │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

- **Firestore Data Model (`firebase-blueprint.json`)**:
  - **`/users/{userId}/private/profile`**: Owner-only PII (`uid`, `fullName`, `email`, `maskedPhone`, `createdAt`, `updatedAt`).
  - **`/donors/{donorId}`**: Publicly readable privacy-masked donor profile (`ownerUid`, `initials`, `bloodGroup`, `city`, `locality`, `lat`, `lng`, `maskedPhone`, `isAvailable`, `lastDonationDate`, `lockedUntil`, `totalDonations`, `verified`, `createdAt`).
  - **`/requests/{requestId}`**: Emergency SOS request (`creatorUid`, `patientName`, `hospitalId`, `hospitalName`, `city`, `locality`, `lat`, `lng`, `bloodGroup`, `unitsNeeded`, `unitsCommitted`, `urgencyLevel`, `deadlineHours`, `expiresAt`, `doctorContact`, `clinicalNotes`, `status`, `createdAt`, `closedAt`).
  - **`/responses/{responseId}`**: Donor pledge (`requestId`, `donorId`, `donorUid`, `donorInitials`, `donorBloodGroup`, `donorLocality`, `distanceKm`, `etaMinutes`, `unitsCommitted`, `status`, `createdAt`).
  - **`/smsLogs/{logId}`**: Simulated SMS dispatch record (`requestId`, `senderUid`, `hospitalName`, `bloodGroup`, `donorId`, `donorInitials`, `donorBloodGroup`, `maskedPhone`, `distanceKm`, `messagePreview`, `deliveryStatus`, `sentAt`).
  - **`/test/connection`**: Connectivity health-check document for `getDocFromServer()`.

- **Interactive Component & State Mapping**:
  - **Geolocation Hook (`useUserLocation`)**: Calls `navigator.geolocation.getCurrentPosition`, stores `{ lat, lng, source: 'gps' | 'manual', accuracy }`, and allows instant fallback to city hubs or manual GPS retry.
  - **Custom Blood-Type Markers (Leaflet & Google Maps)**: Maps each `BloodGroup` (`O-`..`AB+`) to a crisp custom SVG/HTML pin showing the blood group code, urgency ring for critical SOS requests, and distance badge relative to the user's current coordinates.
  - **Firestore Seed & Error Boundary**: On first authenticated session when `/requests` or `/donors` is empty, seeds the 30-donor / 5-request dataset cleanly via batched writes, wrapped in `handleFirestoreError()` + a React `ErrorBoundary`.
  - **Maps Grounding Drawer**: Sends `{ lat, lng, query }` to `POST /api/maps/grounding`, renders the grounded response text alongside verified clickable Google Maps links (`groundingChunks[].maps.uri`), and gracefully surfaces configuration/quota errors without silent fallbacks.
