import 'dotenv/config';
import express from 'express';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import JSZip from 'jszip';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

interface GroundingPlace {
  title: string;
  uri: string;
  snippets: string[];
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // Health endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  // Project source ZIP export (excludes node_modules, dist, .git, .aistudio, and .env secrets)
  app.get('/api/export-zip', async (_req, res) => {
    const ignoredDirs = new Set([
      'node_modules',
      'dist',
      '.git',
      '.aistudio',
      '.cache',
    ]);
    const ignoredFiles = new Set(['.env', '.env.local', '.DS_Store']);

    async function addDirToZip(dirPath: string, zipFolder: JSZip) {
      const entries = await fs.readdir(dirPath, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.isDirectory()) {
          if (ignoredDirs.has(entry.name)) continue;
          const childFolder = zipFolder.folder(entry.name);
          if (childFolder) {
            await addDirToZip(path.join(dirPath, entry.name), childFolder);
          }
        } else if (entry.isFile()) {
          if (ignoredFiles.has(entry.name) || entry.name.endsWith('.zip')) {
            continue;
          }
          const content = await fs.readFile(path.join(dirPath, entry.name));
          zipFolder.file(entry.name, content);
        }
      }
    }

    try {
      const zip = new JSZip();
      const rootFolder = zip.folder('redrelay-lifeline') ?? zip;
      await addDirToZip(__dirname, rootFolder);
      const buffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="redrelay-lifeline.zip"'
      );
      res.setHeader('Cache-Control', 'no-store');
      res.send(buffer);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Failed to package ZIP archive.';
      console.error('Export ZIP Error:', message);
      res.status(500).json({ error: message });
    }
  });

  // Server-side Gemini Maps Grounding route (uses gemini-4-hydrogen + googleMaps tool)
  app.post('/api/maps/grounding', async (req, res) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      res.status(500).json({
        error:
          'GEMINI_API_KEY is not configured on the server. Configure it in Settings > Secrets.',
      });
      return;
    }

    const { query, latitude, longitude } = req.body as {
      query?: string;
      latitude?: number;
      longitude?: number;
    };

    const userPrompt =
      (query && query.trim()) ||
      'Find 24-hour licensed blood banks, hospital transfusion centers, and emergency trauma hospitals nearby with contact info or hours if available.';

    const lat = typeof latitude === 'number' && Number.isFinite(latitude) ? latitude : 17.4156;
    const lng = typeof longitude === 'number' && Number.isFinite(longitude) ? longitude : 78.4347;

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: userPrompt,
        config: {
          tools: [{ googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: {
                latitude: lat,
                longitude: lng,
              },
            },
          },
        },
      });

      const rawChunks =
        response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];

      const places: GroundingPlace[] = [];
      for (const chunk of rawChunks) {
        const mapsData = (chunk as {
          maps?: {
            uri?: string;
            title?: string;
            placeAnswerSources?: {
              reviewSnippets?: Array<{ content?: string }>;
            };
          };
        }).maps;
        if (mapsData?.uri) {
          const snippets =
            mapsData.placeAnswerSources?.reviewSnippets
              ?.map((s) => s.content)
              .filter((s): s is string => Boolean(s)) ?? [];
          places.push({
            title: mapsData.title || 'View on Google Maps',
            uri: mapsData.uri,
            snippets,
          });
        }
      }

      res.json({
        text: response.text ?? '',
        places,
        coordinates: { latitude: lat, longitude: lng },
      });
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Maps Grounding request failed.';
      console.error('Gemini Maps Grounding Error:', message);
      res.status(502).json({ error: message });
    }
  });

  // Server-side multi-turn Gemini Clinical Assistant chat route
  app.post('/api/chat', async (req, res) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      res.status(500).json({
        error:
          'GEMINI_API_KEY is not configured on the server. Configure it in Settings > Secrets.',
      });
      return;
    }

    const { message, history, roleMode } = req.body as {
      message?: string;
      history?: Array<{ role: 'user' | 'model'; text: string }>;
      roleMode?: 'coordinator' | 'donor_advisor' | 'quick_triage';
    };

    if (!message || !message.trim()) {
      res.status(400).json({ error: 'Message cannot be empty.' });
      return;
    }

    const mode = roleMode ?? 'coordinator';
    const model =
      mode === 'quick_triage' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen';

    const systemInstructions: Record<string, string> = {
      coordinator:
        'You are the RedRelay SOS Coordinator Assistant for emergency blood coordination (focused on Hyderabad, Telangana and Indian hospital blood bank protocols). Help families and hospital staff understand ABO/Rh blood compatibility, blood components (Whole Blood, PRBC, Platelets, FFP), cross-match desk preparation, and real-time SOS lifecycle stages (Pending, In Progress, Fulfilled, Closed). Be concise, calm, clinically accurate, and remind users never to share personal donor phone numbers publicly. Do not diagnose medical conditions; direct urgent medical emergencies to hospital doctors.',
      donor_advisor:
        'You are the RedRelay Voluntary Donor Advisor. Guide blood donors on eligibility, the mandatory 90-day post-donation clinical recovery lock policy, hydration/preparation before donating, and privacy-masked relay coordination. Keep responses concise, supportive, and accurate.',
      quick_triage:
        'You are the RedRelay Fast Triage Helper. Provide rapid, bulleted, high-clarity answers on blood group compatibility charts, component turnaround times, and urgent SOS checklists in under 120 words.',
    };

    const formattedHistory = Array.isArray(history)
      ? history
          .filter(
            (item) =>
              item &&
              (item.role === 'user' || item.role === 'model') &&
              typeof item.text === 'string' &&
              item.text.trim().length > 0
          )
          .slice(-20)
          .map((item) => ({
            role: item.role,
            parts: [{ text: item.text.trim() }],
          }))
      : [];

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const chat = ai.chats.create({
        model,
        history: formattedHistory,
        config: {
          systemInstruction:
            systemInstructions[mode] ?? systemInstructions.coordinator,
        },
      });

      const response = await chat.sendMessage({
        message: message.trim(),
      });

      res.json({
        reply: response.text ?? '',
        model,
      });
    } catch (err) {
      const errMessage =
        err instanceof Error ? err.message : 'Gemini chat request failed.';
      console.error('Gemini Chat Error:', errMessage);
      res.status(502).json({ error: errMessage });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RedRelay server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
